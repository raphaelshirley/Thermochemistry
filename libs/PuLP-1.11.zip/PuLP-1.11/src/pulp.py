# PuLP : Python LP Modeler
# Version 1.10

# Copyright (c) 2002-2005, Jean-Sebastien Roy (js@jeannot.org)
# Modifications Copyright (c) 2007 Stuart Anthony Mitchell (s.mitchell@auckland.ac.nz)
# $Id: pulp.py 1791 2008-04-23 22:54:34Z smit023 $

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:

# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
PuLP: An LP modeler in Python

PuLP is an LP modeler written in python. PuLP can generate MPS or LP files
and call GLPK, COIN CLP/CBC, CPLEX and XPRESS to solve linear problems.

Use LpVariable() to create new variables. ex:
x = LpVariable("x", 0, 3)
to create a variable 0 <= x <= 3

Use LpProblem() to create new problems. ex:
prob = LpProblem("myProblem", LpMinimize)

Combine variables to create expressions and constraints and add them to the
problem. ex:
prob += x + y <= 2
If you add an expression (not a constraint, f.e. prob += 4*z + w), it will
become the objective.

Choose a solver and solve the problem. ex:
prob.solve(GLPK())

You can get the value of the variables using value(). ex:
value(x)

Exported Classes:
    - LpProblem -- Container class for a Linear programming problem
    - LpVariable -- Variables that are added to constraints in the LP
    - LpConstraint -- A constraint of the general form 
      a1x1+a2x2 ...anxn (<=, =, >=) b 
    - LpConstraintVar -- Used to construct a column of the model in column-wise 
      modelling

Exported Functions:
    - value() -- Finds the value of a variable or expression
    - lpSum() -- given a list of the form [a1*x1, a2x2, ..., anxn] will construct 
      a linear expression to be used as a constraint or variable
    - lpDot() --given two lists of the form [a1, a2, ..., an] and 
      [ x1, x2, ..., xn]will construct a linear epression to be used 
      as a constraint or variable
"""

import os
import types
import ConfigParser
import collections
import string
from time import clock
from tempfile import mktemp
import sparse

EPS = 1e-7

# variable categories
LpContinuous = 0
LpInteger = 1
LpCategories = {LpContinuous: "Continuous", LpInteger: "Integer"}

# objective sense
LpMinimize = 1
LpMaximize = -1
LpSenses = {LpMaximize:"Maximize", LpMinimize:"Minimize"}

# problem status
LpStatusNotSolved = 0
LpStatusOptimal = 1
LpStatusInfeasible = -1
LpStatusUnbounded = -2
LpStatusUndefined = -3
LpStatus = { LpStatusNotSolved:"Not Solved",
    LpStatusOptimal:"Optimal",
    LpStatusInfeasible:"Infeasible",
    LpStatusUnbounded:"Unbounded",
    LpStatusUndefined:"Undefined",
    }

# constraint sense
LpConstraintLE = -1
LpConstraintEQ = 0
LpConstraintGE = 1
LpConstraintSenses = {LpConstraintEQ:"=", LpConstraintLE:"<=", LpConstraintGE:">="}

# LP line size
LpCplexLPLineSize = 78

#import configuration information
def initialize(file = None):
    """ reads the configuration file to initialise the module"""
    if not file:
        file = __file__
    config = ConfigParser.SafeConfigParser()
    config.read(file)
    cplex_dll_path = config.get("locations","CplexPath")
    coinMP_path = config.get("locations","CoinMPPath")
    if not os.path.dirname(coinMP_path):
        #if no pathname is supplied assume the file is in the same directory
        coinMP_path = os.path.join(os.path.dirname(config_filename),coinMP_path) 
    return cplex_dll_path, coinMP_path

def setConfigInformation(**keywords):
    """
    set the data in the configuration file
    at the moment will only edit things in [locations] 
    the keyword value pairs come from the keywords dictionary
    """
    #TODO: extend if we ever add another section in the config file
    #read the old configuration
    config = ConfigParser.SafeConfigParser()
    config.read(config_filename)
    #set the new keys
    for (key,val) in keywords.items():
        config.set("locations",key,val)
    #write the new configuration
    fp = open(config_filename,"w")
    config.write(fp)
    fp.close()
    


if __name__ != '__main__':
    config_filename = os.path.join(os.path.dirname(__file__),
                                   "pulp.cfg")
else: #run as a script
    from pulp import __file__ as fname
    config_filename = os.path.join(os.path.dirname(fname),
                                   "pulp.cfg")
cplex_dll_path,coinMP_path = initialize(config_filename)

# See later for LpSolverDefault definition
class LpSolver:
    """A generic LP Solver"""

    def __init__(self, mip = 1, msg = 1, options = []):
        self.mip = mip
        self.msg = msg
        self.options = options

    def available(self):
        """True if the solver is available"""
        raise NotImplementedError

    def actualSolve(self, lp):
        """Solve a well formulated lp problem"""
        raise NotImplementedError

    def actualResolve(self,lp):
        """
        uses existing problem information and solves the problem
        If it is not implelemented in the solver
        just solve again
        """
        self.actualSolve(lp)

    def copy(self):
        """Make a copy of self"""
        
        aCopy = self.__class__()
        aCopy.mip = self.mip
        aCopy.msg = self.msg
        aCopy.options = self.options
        return aCopy

    def solve(self, lp):
        """Solve the problem lp"""
        # Always go through the solve method of LpProblem
        return lp.solve(self)
    
    #TODO: Not sure if this code should be here or in a child class
    def getCplexStyleArrays(self,lp,
                       senseDict={LpConstraintEQ:"E", LpConstraintLE:"L", LpConstraintGE:"G"},
                       LpVarCategories = {LpContinuous: "C",LpInteger: "I"},
                       LpObjSenses = {LpMaximize : -1,
                                      LpMinimize : 1},
                       infBound =  1e20 
                       ):
        """returns the arrays suitable to pass to a cdll Cplex
        or other solvers that are similar

        Copyright (c) Stuart Mitchell 2007
        """
        rangeCount = 0
        variables=lp.variables()
        numVars = len(variables)
        #associate each variable with a ordinal
        self.v2n=dict(((variables[i],i) for i in range(numVars)))
        self.vname2n=dict(((variables[i].name,i) for i in range(numVars)))            
        self.n2v=dict((i,variables[i]) for i in range(numVars))
        #objective values
        objSense = LpObjSenses[lp.sense]
        NumVarDoubleArray = ctypes.c_double * numVars
        objectCoeffs=NumVarDoubleArray()
        #print "Get objective Values"
        for v,val in lp.objective.iteritems():
            objectCoeffs[self.v2n[v]]=val
        #values for variables
        NumVarStrArray = ctypes.c_char_p * numVars
        colNames = NumVarStrArray()
        lowerBounds = NumVarDoubleArray()
        upperBounds = NumVarDoubleArray()
        initValues = NumVarDoubleArray()
        if self.debug: print "Get Variable information"
        for v in lp.variables():
            colNames[self.v2n[v]] = str(v.name)
            initValues[self.v2n[v]] = 0.0
            if v.lowBound != None:
                lowerBounds[self.v2n[v]] = v.lowBound
            else:
                lowerBounds[self.v2n[v]] = -infBound
            if v.upBound != None:
                upperBounds[self.v2n[v]] = v.upBound
            else:
                upperBounds[self.v2n[v]] = infBound
        #values for constraints
        numRows =len(lp.constraints)
        NumRowDoubleArray = ctypes.c_double * numRows
        NumRowStrArray = ctypes.c_char_p * numRows
        NumRowCharArray = ctypes.c_char * numRows
        rhsValues = NumRowDoubleArray()
        rangeValues = NumRowDoubleArray()
        rowNames = NumRowStrArray()
        rowType = NumRowCharArray()
        self.c2n = {}
        self.n2c = {}
        i = 0
        if self.debug: print "Get constraint information"
        for c in lp.constraints:
            rhsValues[i] = -lp.constraints[c].constant
            #for ranged constraints a<= constraint >=b
            rangeValues[i] = 0.0
            rowNames[i] = str(c)
            rowType[i] = senseDict[lp.constraints[c].sense]
            self.c2n[c] = i
            self.n2c[i] = c
            i = i+1
        #return the coefficient matrix as a series of vectors
        coeffs = lp.coefficients()
        sparseMatrix = sparse.Matrix(range(numRows), range(numVars))
        for var,row,coeff in coeffs:
            sparseMatrix.add(self.c2n[row], self.vname2n[var], coeff)
        (numels, mystartsBase, mylenBase, myindBase, 
         myelemBase) = sparseMatrix.col_based_arrays() 
        elemBase = ctypesArrayFill(myelemBase, ctypes.c_double)
        indBase = ctypesArrayFill(myindBase, ctypes.c_int)
        startsBase = ctypesArrayFill(mystartsBase, ctypes.c_int)
        lenBase = ctypesArrayFill(mylenBase, ctypes.c_int)
        #MIP Variables
        NumVarCharArray = ctypes.c_char * numVars
        columnType = NumVarCharArray()
        if lp.isMIP():
            for v in lp.variables():
                columnType[self.v2n[v]] = LpVarCategories[v.cat]
        self.addedVars = numVars
        self.addedRows = numRows
        return  numVars, numRows, numels, rangeCount, objSense, objectCoeffs, \
            rhsValues, rangeValues, rowType, startsBase, lenBase, indBase, \
            elemBase, lowerBounds, upperBounds, initValues, colNames, \
            rowNames, columnType, self.n2v, self.n2c


class LpSolver_CMD(LpSolver):
    """A generic command line LP Solver"""
    def __init__(self, path = None, keepFiles = 0, mip = 1, msg = 1, options = []):
        LpSolver.__init__(self, mip, msg, options)
        if path is None:
            self.path = self.defaultPath()
        else:
            self.path = path
        self.keepFiles = keepFiles
        self.setTmpDir()

    def copy(self):
        """Make a copy of self"""
        
        aCopy = LpSolver.copy(self)
        aCopy.path = self.path
        aCopy.keepFiles = self.keepFiles
        aCopy.tmpDir = self.tmpDir
        return aCopy

    def setTmpDir(self):
        """Set the tmpDir attribute to a reasonnable location for a temporary
        directory"""
        if os.name != 'nt':
            # On unix use /tmp by default
            self.tmpDir = os.environ.get("TMPDIR", "/tmp")
            self.tmpDir = os.environ.get("TMP", self.tmpDir)
        else:
            # On Windows use the current directory
            self.tmpDir = os.environ.get("TMPDIR", "")
            self.tmpDir = os.environ.get("TMP", self.tmpDir)
            self.tmpDir = os.environ.get("TEMP", self.tmpDir)
        if not os.path.isdir(self.tmpDir):
            self.tmpDir = ""
        elif not os.access(self.tmpDir, os.F_OK + os.W_OK):
            self.tmpDir = ""

    def defaultPath(self):
        raise NotImplementedError

    def executableExtension(name):
        if os.name != 'nt':
            return name
        else:
            return name+".exe"
    executableExtension = staticmethod(executableExtension)

    def executable(command):
        """Checks that the solver command is executable,
        And returns the actual path to it."""

        if os.path.isabs(command):
            if os.access(command, os.X_OK):
                return command
        for path in os.environ.get("PATH", []).split(os.pathsep):
            if os.access(os.path.join(path, command), os.X_OK):
                return os.path.join(path, command)
        return False
    executable = staticmethod(executable)

class GLPK_CMD(LpSolver_CMD):
    """The GLPK LP solver"""
    def defaultPath(self):
        return self.executableExtension("glpsol")

    def available(self):
        """True if the solver is available"""
        return self.executable(self.path)

    def actualSolve(self, lp):
        """Solve a well formulated lp problem"""
        if not self.executable(self.path):
            raise "PuLP: cannot execute "+self.path
        if not self.keepFiles:
            pid = os.getpid()
            tmpLp = os.path.join(self.tmpDir, "%d-pulp.lp" % pid)
            tmpSol = os.path.join(self.tmpDir, "%d-pulp.sol" % pid)
        else:
            tmpLp = lp.name+"-pulp.lp"
            tmpSol = lp.name+"-pulp.sol"
        lp.writeLP(tmpLp, writeSOS = 0)
        proc = ["glpsol", "--lpt", tmpLp, "-o", tmpSol]
        if not self.mip: proc.append('--nomip')
        proc.extend(self.options)

        self.solution_time = clock()
        if not self.msg:
            proc[0] = self.path
            f = os.popen(" ".join(proc))
            f.read()
            rc = f.close()
            if rc != None:
                raise "PuLP: Error while trying to execute "+self.path
        else:
            if os.name != 'nt':
                rc = os.spawnvp(os.P_WAIT, self.path, proc)
            else:
                rc = os.spawnv(os.P_WAIT, self.executable(self.path), proc)
            if rc == 127:
                raise "PuLP: Error while trying to execute "+self.path
        self.solution_time += clock()

        if not os.path.exists(tmpSol):
            raise "PuLP: Error while executing "+self.path
        lp.status, values = self.readsol(tmpSol)
        lp.assignVarsVals(values)
        if not self.keepFiles:
            try: os.remove(tmpLp)
            except: pass
            try: os.remove(tmpSol)
            except: pass
        return lp.status

    def readsol(self,filename):
        """Read a GLPK solution file"""
        f = file(filename)
        f.readline()
        rows = int(f.readline().split()[1])
        cols = int(f.readline().split()[1])
        f.readline()
        statusString = f.readline()[12:-1]
        glpkStatus = {
            "INTEGER OPTIMAL":LpStatusOptimal,
            "OPTIMAL":LpStatusOptimal,
            "INFEASIBLE (FINAL)":LpStatusInfeasible,
            "INTEGER UNDEFINED":LpStatusUndefined,
            "UNBOUNDED":LpStatusUnbounded,
            "UNDEFINED":LpStatusUndefined,
            "INTEGER EMPTY":LpStatusInfeasible
            }
        if statusString not in glpkStatus:
            raise ValueError, "Unknow status returned by GLPK"
        status = glpkStatus[statusString]
        isInteger = statusString in ["INTEGER OPTIMAL","INTEGER UNDEFINED"]
        values = {}
        for i in range(4): f.readline()
        for i in range(rows):
            line = f.readline().split()
            if len(line) ==2: f.readline()
        for i in range(3):
            f.readline()
        for i in range(cols):
            line = f.readline().split()
            name = line[1]
            if len(line) ==2: line = [0,0]+f.readline().split()
            if isInteger:
                if line[2] == "*": value = int(line[3])
                else: value = float(line[2])
            else:
                value = float(line[3])
            values[name] = value
        return status, values

try:
    import pulpGLPK
    
    class GLPK_MEM(LpSolver):
        """The GLPK LP solver (via a module)"""
        def __init__(self, mip = 1, msg = 1, presolve = 1):
            LpSolver.__init__(self, mip, msg)
            self.presolve = presolve

        def copy(self):
            """Make a copy of self"""
        
            aCopy = LpSolver.copy()
            aCopy.presolve = self.presolve
            return aCopy

        def available(self):
            """True if the solver is available"""
            return True

        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            lp.status = pulpGLPK.solve(lp.objective, lp.constraints, lp.sense, self.msg,
                self.mip, self.presolve)
            return lp.status
    
    GLPK = GLPK_MEM
except:
    class GLPK_MEM(LpSolver):
        """The GLPK LP solver (via a module)"""
        def available(self):
            """True if the solver is available"""
            return False

        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            raise RuntimeError, "GLPK_MEM: Not Available"

    GLPK = GLPK_CMD

class CPLEX_CMD(LpSolver_CMD):
    """The CPLEX LP solver"""
    def defaultPath(self):
        return self.executableExtension("cplex")

    def available(self):
        """True if the solver is available"""
        return self.executable(self.path)

    def actualSolve(self, lp):
        """Solve a well formulated lp problem"""
        if not self.executable(self.path):
            raise "PuLP: cannot execute "+self.path
        if not self.keepFiles:
            pid = os.getpid()
            tmpLp = os.path.join(self.tmpDir, "%d-pulp.lp" % pid)
            # Should probably use another CPLEX solution format
            tmpSol = os.path.join(self.tmpDir, "%d-pulp.txt" % pid)
        else:
            tmpLp = lp.name+"-pulp.lp"
            # Should probably use another CPLEX solution format
            tmpSol = lp.name+"-pulp.txt"
        lp.writeLP(tmpLp, writeSOS = 1)
        try: os.remove(tmpSol)
        except: pass
        if not self.msg:
            #TODO make this work properly in windows
            #cplex = os.popen(self.path+" > /dev/null 2> /dev/null", "w")
            cplex = os.popen(self.path, "w")
        else:
            cplex = os.popen(self.path, "w")
        cplex.write("read "+tmpLp+"\n")
        for option in self.options:
            cplex.write(option+"\n")
        if lp.isMIP():
            if self.mip:
                cplex.write("mipopt\n")
                cplex.write("change problem fixed\n")
            else:
                cplex.write("change problem lp\n")
                
        cplex.write("optimize\n")
        cplex.write("write "+tmpSol+"\n")
        cplex.write("quit\n")
        if cplex.close() != None:
            #TODO: Will need to fix the solution file reading of Cplex
            raise "PuLP: Error while trying to execute "+self.path
        if not self.keepFiles:
            try: os.remove(tmpLp)
            except: pass
        if not os.path.exists(tmpSol):
            status = LpStatusInfeasible
        else:
            status, values, reducedCosts, shadowPrices, slacks = self.readsol(tmpSol)
        if not self.keepFiles:
            try: os.remove(tmpSol)
            except: pass
            try: os.remove("cplex.log")
            except: pass
        if status != LpStatusInfeasible:
            lp.assignVarsVals(values)
            lp.assignVarsDj(reducedCosts)                          
            lp.assignConsPi(shadowPrices)
            lp.assignConsSlack(slacks)          
        lp.status = status
        return status

    def readsol(self,filename):
        """Read a CPLEX solution file"""
        f = file(filename)
        for i in range(3): f.readline()
        statusString = f.readline()[18:30]
        cplexStatus = {
            "OPTIMAL SOLN":LpStatusOptimal,
            }
        if statusString not in cplexStatus:
            raise ValueError, "Unknown status returned by CPLEX: "+statusString
        status = cplexStatus[statusString]
        
        for i in range(13): f.readline()
        shadowPrices = {}
        slacks = {}
        shadowPrices = {}
        slacks = {}
        while 1:
            l = f.readline()
            if l[:10] == " SECTION 2": break
            line = l[3:].split()
            if len(line):
                name = line[1]
                shadowPrice = line[7]
                slack = line[4]
                #TODO investigate why this is negative
                shadowPrices[name] = -float(shadowPrice)
                slacks[name] = slack
        
        for i in  range(3): f.readline()
        values = {}
        reducedCosts = {}
        while 1:
            l = f.readline()
            if l == "": break
            line = l[3:].split()
            if len(line):
                name = line[1]
                value = float(line[3])
                reducedCost = float(line[7])
                values[name] = value
                reducedCosts[name] = reducedCost

        return status, values, reducedCosts, shadowPrices, slacks

try:
    import pulpCPLEX
    
    class CPLEX_MEM(LpSolver):
        """The CPLEX LP solver (via a module)"""
        def __init__(self, mip = 1, msg = 1, timeLimit = -1):
            LpSolver.__init__(self, mip, msg)
            self.timeLimit = timeLimit

        def available(self):
            """True if the solver is available"""
            return True

        def grabLicence(self):
            """Returns True if a CPLEX licence can be obtained.
            The licence is kept until releaseLicence() is called."""
            return pulpCPLEX.grabLicence()

        def releaseLicence(self):
            """Release a previously obtained CPLEX licence"""
            pulpCPLEX.releaseLicence()

        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            lp.status = pulpCPLEX.solve(lp.objective, lp.constraints, lp.sense, self.msg,
                self.mip, self.timeLimit)
            return lp.status
    
    CPLEX = CPLEX_MEM
except:
    class CPLEX_MEM(LpSolver):
        """The CPLEX LP solver (via a module)"""
        def available(self):
            """True if the solver is available"""
            return False
        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            raise RuntimeError, "CPLEX_MEM: Not Available"

    CPLEX = CPLEX_CMD
try:
    import ctypes
    if os.name in ['nt','dos']:
        CplexDll = ctypes.windll.LoadLibrary(cplex_dll_path)
    else:
        CplexDll = ctypes.cdll.LoadLibrary(cplex_dll_path)
        
    class CPLEX_DLL(LpSolver):
        """The CPLEX LP/MIP solver (via a Dynamic library DLL - windows or SO - Linux)"""
        def __init__(self, mip = 1, msg = 1, timeLimit = -1, debug = False):
            LpSolver.__init__(self, mip, msg)
            self.timeLimit = timeLimit
            self.debug = debug
            self.grabLicence()

        def findSolutionValues(self, lp, numcols, numrows):
            byref = ctypes.byref
            solutionStatus = ctypes.c_int()
            objectiveValue = ctypes.c_double()
            x = (ctypes.c_double * numcols)()
            pi = (ctypes.c_double * numrows)()
            slack = (ctypes.c_double * numrows)()
            dj = (ctypes.c_double * numcols)()
            status= CplexDll.CPXsolwrite(self.env, self.hprob, "CplexTest.sol")
            if lp.isMIP():
                solutionStatus.value = CplexDll.CPXgetstat(self.env, self.hprob)
                status = CplexDll.CPXgetobjval(self.env, self.hprob, byref(objectiveValue))
                if status != 0 and status != 1217: #no solution exists
                    raise RuntimeError, ("Error in CPXgetobjval status=" + str(status))
                
                status = CplexDll.CPXgetx(self.env, self.hprob, byref(x), 0, numcols - 1)
                if status != 0 and status != 1217:
                    raise RuntimeError, "Error in CPXgetx status=" + str(status)
                
            else:
                status = CplexDll.CPXsolution(self.env, self.hprob, byref(solutionStatus), 
                                              byref(objectiveValue), byref(x), byref(pi), 
                                              byref(slack), byref(dj))
            CplexLpStatus = collections.defaultdict(lambda : LpStatusUndefined)
            CplexLpStatus.update({1: LpStatusOptimal, 3: LpStatusInfeasible, 
                                  2: LpStatusUnbounded, 0: LpStatusNotSolved, 
                                  101: LpStatusOptimal, 103: LpStatusInfeasible})
            #populate pulp solution values
            variablevalues = {}
            variabledjvalues = {}
            constraintpivalues = {}
            constraintslackvalues = {}
            for i in range(numcols):
                variablevalues[self.n2v[i].name] = x[i]
                variabledjvalues[self.n2v[i].name] = dj[i]
            lp.assignVarsVals(variablevalues)
            lp.assignVarsDj(variabledjvalues)            
            #put pi and slack variables against the constraints
            for i in range(numrows):
                constraintpivalues[self.n2c[i]] = pi[i]
                constraintslackvalues[self.n2c[i]] = slack[i]                
            lp.assignConsPi(constraintpivalues)
            lp.assignConsSlack(constraintslackvalues)
            
            #TODO: clear up the name of self.n2c
            
            if self.msg:
                print "Cplex status=", solutionStatus.value
            lp.resolveOK = True
            for var in lp.variables():
                var.isModified = False
            lp.status = CplexLpStatus[solutionStatus.value]
            return lp.status


        def __del__(self):
            #LpSolver.__del__(self)
            self.releaseLicence()


        def available(self):
            """True if the solver is available"""
            return True

        def grabLicence(self):
            """Returns True if a CPLEX licence can be obtained.
            The licence is kept until releaseLicence() is called."""
            status = ctypes.c_int()
            self.env = CplexDll.CPXopenCPLEX(ctypes.byref(status))
            if not(status.value == 0):
                raise RuntimeError, "CPLEX library failed on CPXopenCPLEX status=" + str(status)
            

        def releaseLicence(self):
            """Release a previously obtained CPLEX licence"""
            if getattr(self,"env",False):
                status=CplexDll.CPXcloseCPLEX(self.env)
            else:
                raise RuntimeError, "No CPLEX enviroment to close"

        def callSolver(self, isMIP):
            """Solves the problem with cplex
            """
            #output an mps file for debug
            SOLV_FILE_MPS=1
            if self.debug: 
                status = CplexDll.CPXwriteprob (self.env, self.hprob, "CplexTest.lp", None);
                if status != 0:
                    raise RuntimeError, "Error in CPXwriteprob status=" + str(status) 
            #solve the problem
            if self.debug:
                print "About to solve"
            self.cplexTime = -clock()
            if isMIP and self.mip:
                status= CplexDll.CPXmipopt(self.env, self.hprob)
                if status != 0:
                    raise RuntimeError, "Error in CPXmipopt status=" + str(status)
            else:
                status = CplexDll.CPXlpopt(self.env, self.hprob)
                if status != 0:
                    raise RuntimeError, "Error in CPXlpopt status=" + str(status)
            self.cplexTime += clock()
            if self.debug:
                print "finished solving"


        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            #TODO alter so that msg parameter is handled correctly
            status = ctypes.c_int()
            byref = ctypes.byref   #shortcut to function
            self.hprob = CplexDll.CPXcreateprob(self.env, byref(status), lp.name)
            if status.value != 0:
                raise RuntimeError, "Error in CPXcreateprob status=" + str(status) 
            if self.debug: print "Before getCplexDllArrays"
            numcols, numrows, numels, rangeCount, objSense, obj, \
                rhs, rangeValues, rowSense, matbeg, matcnt, matind, \
                matval, lb, ub, initValues, colname, \
                rowname, xctype, n2v, n2c = self.getCplexStyleArrays(lp)
            status.value = CplexDll.CPXcopylpwnames (self.env, self.hprob, numcols, numrows,
                                 objSense, obj, rhs, rowSense, matbeg, matcnt,
                                 matind, matval, lb, ub, None, colname, rowname);
            if status.value != 0:
                raise RuntimeError, "Error in CPXcopylpwnames status=" + str(status) 
            if lp.isMIP() and self.mip:
                status.value = CplexDll.CPXcopyctype(self.env, self.hprob, xctype)
            if status.value != 0:
                raise RuntimeError, "Error in CPXcopyctype status=" + str(status) 
            #set the initial solution            
            self.callSolver(lp.isMIP())
            #get the solution information
            solutionStatus = self.findSolutionValues(lp, numcols, numrows)          
            for var in lp.variables():
                var.modified = False
            return solutionStatus

        
        def actualResolve(self,lp):
            """looks at which variables have been modified and changes them
            """
            #TODO: Add changing variables not just adding them
            #TODO: look at constraints
            modifiedVars = [var for var in lp.variables() if var.modified] 
            #assumes that all variables flagged as modified need to be added to the 
            #problem
            newVars = modifiedVars 
            #print newVars
            self.v2n.update([(var, i+self.addedVars) for i,var in enumerate(newVars)])
            self.n2v.update([(i+self.addedVars, var) for i,var in enumerate(newVars)])
            self.vname2n.update([(var.name, i+self.addedVars) for i,var in enumerate(newVars)])
            oldVars = self.addedVars
            self.addedVars += len(newVars)
            (ccnt,nzcnt,obj,cmatbeg, cmatlen, cmatind,cmatval,lb,ub, initvals,
             colname, coltype) = self.getSparseCols(newVars, lp, oldVars, defBound = 1e20)
            CPXaddcolsStatus = CplexDll.CPXaddcols(self.env, self.hprob,
                                          ccnt, nzcnt,
                                          obj,cmatbeg, 
                                          cmatind,cmatval, 
                                          lb,ub,colname)
#            columnTypestatus = CplexDll.CPXaddcols(self.env, self.hprob,
#                                          ccnt, nzcnt,
#                                          obj,cmatbeg, 
#                                          cmatind,cmatval, 
#                                          lb,ub,colname)
            #add the column types
            if lp.isMIP() and self.mip:
                indices = (ctypes.c_int * len(newVars))()
                for i,var in enumerate(newVars):
                    indices[i] = oldVars +i
                CPXchgctypeStatus = CplexDll.CPXchgctype (self.env, self.hprob,
                                                 ccnt, indices, coltype);
            #solve the problem
            self.callSolver(lp.isMIP())
            #get the solution information
            solutionStatus = self.findSolutionValues(lp, self.addedVars, self.addedRows)          
           
            for var in modifiedVars:
                var.modified = False
            return solutionStatus
                
        def getSparseCols(self, vars, lp, offset = 0, defBound = 1e20):
            """outputs the variables in var as a sparse matrix,
            suitable for cplex and Coin

            Copyright (c) Stuart Mitchell 2007
            """
            numVars = len(vars)
            obj = (ctypes.c_double * numVars)()
            cmatbeg = (ctypes.c_int * numVars)()
            mycmatind = []
            mycmatval = []
            rangeCount = 0
            #values for variables
            colNames =  (ctypes.c_char_p * numVars)()
            lowerBounds =  (ctypes.c_double * numVars)()
            upperBounds =  (ctypes.c_double * numVars)()
            initValues =  (ctypes.c_double * numVars)()
            if self.debug: print "Get Variable information"
            i=0
            for v in vars:
                colNames[i] = str(v.name)
                initValues[i] = v.init
                if v.lowBound != None:
                    lowerBounds[i] = v.lowBound
                else:
                    lowerBounds[i] = -defBound
                if v.upBound != None:
                    upperBounds[i] = v.upBound
                else:
                    upperBounds[i] = defBound
                i+= 1
                #create the new variables    
            #values for constraints
            #return the coefficient matrix as a series of vectors
            #return the coefficient matrix as a series of vectors
            myobjectCoeffs = {}
            numRows = len(lp.constraints)
            sparseMatrix = sparse.Matrix(range(numRows), range(numVars))
            for var in vars:
                for row,coeff in var.expression.iteritems():
                   if row.name == lp.objective.name:
                        myobjectCoeffs[var] = coeff
                   else:
                        sparseMatrix.add(self.c2n[row.name], self.v2n[var] - offset, coeff)
            #objective values
            objectCoeffs = (ctypes.c_double * numVars)()
            for var in vars:
                objectCoeffs[self.v2n[var]-offset] = myobjectCoeffs[var]
            (numels, mystartsBase, mylenBase, myindBase, 
             myelemBase) = sparseMatrix.col_based_arrays() 
            elemBase = ctypesArrayFill(myelemBase, ctypes.c_double)
            indBase = ctypesArrayFill(myindBase, ctypes.c_int)
            startsBase = ctypesArrayFill(mystartsBase, ctypes.c_int)
            lenBase = ctypesArrayFill(mylenBase, ctypes.c_int)
            #MIP Variables
            NumVarCharArray = ctypes.c_char * numVars
            columnType = NumVarCharArray()
            if lp.isMIP():
                CplexLpCategories = {LpContinuous: "C",
                                    LpInteger: "I"}
                for v in vars:
                    columnType[self.v2n[v] - offset] = CplexLpCategories[v.cat]
            return  numVars, numels,  objectCoeffs, \
                startsBase, lenBase, indBase, \
                elemBase, lowerBounds, upperBounds, initValues, colNames, \
                columnType
             
            
        
    CPLEX = CPLEX_DLL
except:
    class CPLEX_DLL(LpSolver):
        """The CPLEX LP/MIP solver (via a Dynamic library DLL - windows or SO - Linux)"""
        def available(self):
            """True if the solver is available"""
            return False
        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            raise RuntimeError, "CPLEX_DLL: Not Available"



class XPRESS(LpSolver_CMD):
    """The XPRESS LP solver"""
    def defaultPath(self):
        return self.executableExtension("optimizer")

    def available(self):
        """True if the solver is available"""
        return self.executable(self.path)

    def actualSolve(self, lp):
        """Solve a well formulated lp problem"""
        if not self.executable(self.path):
            raise "PuLP: cannot execute "+self.path
        if not self.keepFiles:
            pid = os.getpid()
            tmpLp = os.path.join(self.tmpDir, "%d-pulp.lp" % pid)
            tmpSol = os.path.join(self.tmpDir, "%d-pulp.prt" % pid)
        else:
            tmpLp = lp.name+"-pulp.lp"
            tmpSol = lp.name+"-pulp.prt"
        lp.writeLP(tmpLp, writeSOS = 1, mip = self.mip)
        if not self.msg:
            xpress = os.popen(self.path+" "+lp.name+" > /dev/null 2> /dev/null", "w")
        else:
            xpress = os.popen(self.path+" "+lp.name, "w")
        xpress.write("READPROB "+tmpLp+"\n")
        if lp.sense == LpMaximize:
            xpress.write("MAXIM\n")
        else:
            xpress.write("MINIM\n")
        if lp.isMIP() and self.mip:
            xpress.write("GLOBAL\n")
        xpress.write("WRITEPRTSOL "+tmpSol+"\n")
        xpress.write("QUIT\n")
        if xpress.close() != None:
            raise "PuLP: Error while executing "+self.path
        status, values = self.readsol(tmpSol)
        if not self.keepFiles:
            try: os.remove(tmpLp)
            except: pass
            try: os.remove(tmpSol)
            except: pass
        lp.status = status
        lp.assignVarsVals(values)
        if abs(lp.infeasibilityGap(self.mip)) > 1e-5: # Arbitrary
            lp.status = LpStatusInfeasible
        return lp.status

    def readsol(self,filename):
        """Read an XPRESS solution file"""
        f = file(filename)
        for i in range(6): f.readline()
        l = f.readline().split()

        rows = int(l[2])
        cols = int(l[5])
        for i in range(3): f.readline()
        statusString = f.readline().split()[0]
        xpressStatus = {
            "Optimal":LpStatusOptimal,
            }
        if statusString not in xpressStatus:
            raise ValueError, "Unknow status returned by XPRESS: "+statusString
        status = xpressStatus[statusString]
        values = {}
        while 1:
            l = f.readline()
            if l == "": break
            line = l.split()
            if len(line) and line[0] == 'C':
                name = line[2]
                value = float(line[4])
                values[name] = value
        return status, values

class COIN_CMD(LpSolver_CMD):
    """The COIN CLP/CBC LP solver"""
    def defaultPath(self):
        return (self.executableExtension("clp"), self.executableExtension("cbc"))

    def __init__(self, path = None, keepFiles = 0, mip = 1,
            msg = 1, cuts = 1, presolve = 1, dual = 1, strong = 5, options = []):
        """Here, path is a tuple containing the path to clp and cbc"""
        LpSolver_CMD.__init__(self, path, keepFiles, mip, msg, options)
        self.cuts = cuts
        self.presolve = presolve
        self.dual = dual
        self.strong = strong

    def copy(self):
        """Make a copy of self"""
        
        aCopy = LpSolver_CMD.copy(self)
        aCopy.cuts = self.cuts
        aCopy.presolve = self.presolve
        aCopy.dual = self.dual
        aCopy.strong = self.strong
        return aCopy

    def actualSolve(self, lp):
        """Solve a well formulated lp problem"""
        if lp.isMIP() and self.mip: return self.solve_CBC(lp)
        else: return self.solve_CLP(lp)

    def available(self):
        """True if the solver is available"""
        return self.executable(self.path[0]) and \
            self.executable(self.path[1])

    def solve_CBC(self, lp):
        """Solve a MIP problem using CBC"""
        if not self.executable(self.path[1]):
            raise "PuLP: cannot execute "+self.path[1]
        if not self.keepFiles:
            pid = os.getpid()
            tmpLp = os.path.join(self.tmpDir, "%d-pulp.mps" % pid)
            tmpSol = os.path.join(self.tmpDir, "%d-pulp.sol" % pid)
        else:
            tmpLp = lp.name+"-pulp.mps"
            tmpSol = lp.name+"-pulp.sol"
        vs, variablesNames, constraintsNames, objectiveName = lp.writeMPS(tmpLp, rename = 1)
#        if not self.msg:
#            cbc = os.popen(self.path[1]+" - > /dev/null 2> /dev/null","w")
#        else:
#            cbc = os.popen(self.path[1]+" -","w")
        #TODO make this os agnostic 
        cbc = os.popen(self.path[1]+" -","w")
        cbc.write("import "+tmpLp+"\n")
        if self.presolve:
            cbc.write("presolve on\n")
        cbc.write("strong %d\n" % self.strong)
        if self.cuts:
            cbc.write("gomory on\n")
            cbc.write("oddhole on\n")
            cbc.write("knapsack on\n")
            cbc.write("probing on\n")
        for option in self.options:
            cbc.write(option+"\n")
        if lp.sense == LpMinimize:
            cbc.write("min\n")
        else:
            cbc.write("max\n")
        if self.mip:
            cbc.write("branch\n")
        else:
            cbc.write("initialSolve\n")
        cbc.write("solution "+tmpSol+"\n")
        cbc.write("quit\n")
        if cbc.close() != None:
            raise "PuLP: Error while trying to execute "+self.path[1]
        if not os.path.exists(tmpSol):
            raise "PuLP: Error while executing "+self.path[1]
        lp.status, values = self.readsol_CBC(tmpSol, lp, vs)
        lp.assignVarsVals(values)
        if not self.keepFiles:
            try: os.remove(tmpLp)
            except: pass
            try: os.remove(tmpSol)
            except: pass
        return lp.status

    def solve_CLP(self, lp):
        """Solve a problem using CLP"""
        if not self.executable(self.path[0]):
            raise "PuLP: cannot execute "+self.path[0]
        if not self.keepFiles:
            pid = os.getpid()
            tmpLp = os.path.join(self.tmpDir, "%d-pulp.mps" % pid)
            tmpSol = os.path.join(self.tmpDir, "%d-pulp.sol" % pid)
        else:
            tmpLp = lp.name+"-pulp.mps"
            tmpSol = lp.name+"-pulp.sol"
        vs, variablesNames, constraintsNames, objectiveName = lp.writeMPS(tmpLp, rename = 1)
        if not self.msg:
            clp = os.popen(self.path[0]+" - > /dev/null 2> /dev/null","w")
        else:
            clp = os.popen(self.path[0]+" -","w")
        clp.write("import "+tmpLp+"\n")
        if self.presolve:
            clp.write("presolve on\n")
        for option in self.options:
            clp.write(option+"\n")
        if lp.sense == LpMinimize:
            clp.write("min\n")
        else:
            clp.write("max\n")
        if self.dual:
            clp.write("dualS\n")
        else:
            clp.write("primalS\n")
        clp.write("solution "+tmpSol+"\n")
        clp.write("quit\n")
        if clp.close() != None:
            raise "PuLP: Error while trying to execute "+self.path[0]
        if not os.path.exists(tmpSol):
            raise "PuLP: Error while executing "+self.path[0]
        lp.status, values = self.readsol_CLP(tmpSol, lp, vs, variablesNames, constraintsNames, objectiveName)
        lp.assignVarsVals(values)
        if not self.keepFiles:
            try: os.remove(tmpLp)
            except: pass
            try: os.remove(tmpSol)
            except: pass
        return lp.status

    def readsol_CLP(self,filename, lp, vs, variablesNames, constraintsNames, objectiveName):
        """Read a CLP solution file"""
        values = {}

        reverseVn = {}
        for k,n in variablesNames.iteritems():
            reverseVn[n] = k

        for v in vs:
            values[v.name] = 0.0

        status = LpStatusOptimal # status is very approximate
        f = file(filename)
        for l in f:
            if len(l)<=2: break
            if l[:2] == "**":
                status = LpStatusInfeasible
                l = l[2:]
            l = l.split()
            vn = l[1]
            if vn in reverseVn:
                values[reverseVn[vn]] = float(l[2])
        return status, values

    def readsol_CBC(self,filename, lp, vs):
        """Read a CBC solution file"""
        f = file(filename)
        for i in range(len(lp.constraints)): f.readline()
        values = {}
        for v in vs:
            l = f.readline().split()
            values[v.name] = float(l[1])
        status = LpStatusUndefined # No status info
        return status, values

try:
    import pulpCOIN
    
    class COIN_MEM(LpSolver):
        """The COIN LP solver (via a module)"""
        def __init__(self, mip = 1, msg = 1, cuts = 1, presolve = 1, dual = 1,
            crash = 0, scale = 1, rounding = 1, integerPresolve = 1, strong = 5):
            LpSolver.__init__(self, mip, msg)
            self.cuts = cuts
            self.presolve = presolve
            self.dual = dual
            self.crash = crash
            self.scale = scale
            self.rounding = rounding
            self.integerPresolve = integerPresolve
            self.strong = strong

        def copy(self):
            """Make a copy of self"""
        
            aCopy = LpSolver.copy()
            aCopy.cuts = self.cuts
            aCopy.presolve = self.presolve
            aCopy.dual = self.dual
            aCopy.crash = self.crash
            aCopy.scale = self.scale
            aCopy.rounding = self.rounding
            aCopy.integerPresolve = self.integerPresolve
            aCopy.strong = self.strong
            return aCopy

        def available(self):
            """True if the solver is available"""
            return True

        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            lp.status = pulpCOIN.solve(lp.objective, lp.constraints, lp.sense, 
                self.msg, self.mip, self.presolve, self.dual, self.crash, self.scale,
                self.rounding, self.integerPresolve, self.strong, self.cuts)
            return lp.status
    
    COIN = COIN_MEM
except:
    class COIN_MEM(LpSolver):
        """The COIN LP solver (via a module)"""
        def available(self):
            """True if the solver is available"""
            return False
        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            raise RuntimeError, "COIN_MEM: Not Available"

    COIN = COIN_CMD
try:
    import ctypes
    CoinMP=ctypes.cdll.LoadLibrary(coinMP_path)
    
    class COINMP_DLL(LpSolver):
        """The COIN_MP LP/MIP solver (via a DLL windows only)"""
        COIN_INT_LOGLEVEL = 7
        COIN_REAL_MAXSECONDS = 16
        COIN_REAL_MIPMAXSEC = 19
        COIN_REAL_MIPFRACGAP = 34
        def __init__(self, mip = 1, msg = 1, cuts = 1, presolve = 1, dual = 1,
            crash = 0, scale = 1, rounding = 1, integerPresolve = 1, strong = 5,
            maxSeconds = None, fracGap = None):
            LpSolver.__init__(self, mip, msg)
            self.maxSeconds = None
            if maxSeconds is not None:
                self.maxSeconds = float(maxSeconds)
            self.fracGap = None
            if fracGap is not None:
                self.fracGap = float(fracGap)
            #Todo: these options are not yet implemented
            self.cuts = cuts
            self.presolve = presolve
            self.dual = dual
            self.crash = crash
            self.scale = scale
            self.rounding = rounding
            self.integerPresolve = integerPresolve
            self.strong = strong

        def copy(self):
            """Make a copy of self"""
        
            aCopy = LpSolver.copy()
            aCopy.cuts = self.cuts
            aCopy.presolve = self.presolve
            aCopy.dual = self.dual
            aCopy.crash = self.crash
            aCopy.scale = self.scale
            aCopy.rounding = self.rounding
            aCopy.integerPresolve = self.integerPresolve
            aCopy.strong = self.strong
            return aCopy

        def available(self):
            """True if the solver is available"""
            return True

        def getSolverVersion(self):
            """
            returns a solver version string 
             
            example:
            >>> COINMP_DLL().getSolverVersion() # doctest: +ELLIPSIS
            '...'
            """
            CoinMP.get_version.restype = ctypes.c_char_p
            return CoinMP.get_version()
            


        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            #TODO alter so that msg parameter is handled correctly
            self.debug = 0
            #initialise solver
            CoinMP.CoinInitSolver("")
            #create problem
            hProb = CoinMP.CoinCreateProblem(lp.name);
            #set problem options
            if self.maxSeconds:
                if self.mip:
                    CoinMP.CoinSetRealOption(hProb, self.COIN_REAL_MIPMAXSEC,
                                          ctypes.c_double(self.maxSeconds))
                else:
                    CoinMP.CoinSetRealOption(hProb, self.COIN_REAL_MAXSECONDS,
                                          ctypes.c_double(self.maxSeconds))
            if self.fracGap:
               #Hopefully this is the bound gap tolerance
               CoinMP.CoinSetRealOption(hProb, self.COIN_REAL_MIPFRACGAP,
                                          ctypes.c_double(self.fracGap))
            #coinDblMax is needed for varibles with no bounds
            CoinMP.CoinGetRealMax.restype = ctypes.c_double
            coinDblMax = CoinMP.CoinGetRealMax()
            if self.debug: print "Before getCoinMPArrays"
            numVars, numRows, numels, rangeCount,objectSense, objectCoeffs, \
                rhsValues, rangeValues, rowType, startsBase, \
                lenBase, indBase, \
                elemBase, lowerBounds, upperBounds, initValues, colNames, \
                rowNames, columnType, n2v, n2c = self.getCplexStyleArrays(lp)
            CoinMP.CoinLoadProblem(hProb, numVars, numRows,
                                   numels, rangeCount,
                                   objectSense, objectCoeffs,
                                   rhsValues, rangeValues,
                                   rowType, startsBase,
                                   lenBase, indBase,
                                   elemBase, lowerBounds,
                                   upperBounds, initValues,
                                   colNames, rowNames )
            if lp.isMIP() and self.mip:
                CoinMP.CoinLoadInteger(hProb,columnType)
            if self.msg == 0:
                #close stdout to get rid of messages
                tempfile = open(mktemp(),'w')
                savestdout = os.dup(1)
                os.close(1)
                if os.dup(tempfile.fileno()) != 1:
                    raise RuntimeError, "couldn't redirect stdout - dup() error"
            self.coinTime = -clock()
            CoinMP.CoinOptimizeProblem(hProb, 0);
            self.coinTime += clock()

            if self.msg == 0:
                #reopen stdout
                os.close(1)
                os.dup(savestdout)
           
            CoinMP.CoinGetSolutionText.restype=ctypes.c_char_p
            CoinMP.CoinGetObjectValue.restype=ctypes.c_double
            CoinLpStatus = {0:LpStatusOptimal,
                            1:LpStatusInfeasible,
                            2:LpStatusInfeasible,
                            3:LpStatusNotSolved,
                            4:LpStatusNotSolved,
                            5:LpStatusNotSolved,
                            -1:LpStatusUndefined
                            }
            solutionStatus = CoinMP.CoinGetSolutionStatus(hProb)
            solutionText = CoinMP.CoinGetSolutionText(hProb,solutionStatus)
            objectValue =  CoinMP.CoinGetObjectValue(hProb)

            #get the solution values
            NumVarDoubleArray = ctypes.c_double * numVars
            NumRowsDoubleArray = ctypes.c_double * numRows
            cActivity = NumVarDoubleArray()
            cReducedCost = NumVarDoubleArray()
            cSlackValues = NumRowsDoubleArray()
            cShadowPrices = NumRowsDoubleArray()
            CoinMP.CoinGetSolutionValues(hProb, ctypes.byref(cActivity),
                                         ctypes.byref(cReducedCost),
                                         ctypes.byref(cSlackValues),
                                         ctypes.byref(cShadowPrices))

            variablevalues = {}
            variabledjvalues = {}
            constraintpivalues = {}
            constraintslackvalues = {}
            for i in range(numVars):
                variablevalues[self.n2v[i].name] = cActivity[i]
                variabledjvalues[self.n2v[i].name] = cReducedCost[i]
            lp.assignVarsVals(variablevalues)
            lp.assignVarsDj(variabledjvalues)            
            #put pi and slack variables against the constraints
            for i in range(numRows):
                constraintpivalues[self.n2c[i]] = cShadowPrices[i]
                constraintslackvalues[self.n2c[i]] = rhsValues[i] - cSlackValues[i]                
            lp.assignConsPi(constraintpivalues)
            lp.assignConsSlack(constraintslackvalues)
                       
            CoinMP.CoinFreeSolver()
            lp.status = CoinLpStatus[CoinMP.CoinGetSolutionStatus(hProb)]
            return lp.status

        def getCoinMPArrays(self,lp,coinDblMax):
            """returns the arrays suitable to pass to a cdll CoinMP

            Copywrite (c) Stuart Mitchell 2007
            """
            rangeCount = 0
            objectSense = lp.sense
            vars=lp.variables()
            numVars = len(vars)
            #print "In getCoinMPArrays"
            #associate each variable with a ordinal
            v2n=dict(((vars[i],i) for i in range(numVars)))
            vname2n=dict(((vars[i].name,i) for i in range(numVars)))            
            n2v=dict((i,vars[i]) for i in range(numVars))
            #print "After Dictionaries"
            #objective values
            NumVarDoubleArray = ctypes.c_double * numVars
            objectCoeffs=NumVarDoubleArray()
            print "Get objective Values"
            for v,val in lp.objective.iteritems():
                objectCoeffs[v2n[v]]=val
            #values for variables
            NumVarStrArray = ctypes.c_char_p * numVars
            colNames = NumVarStrArray()
            lowerBounds = NumVarDoubleArray()
            upperBounds = NumVarDoubleArray()
            initValues = NumVarDoubleArray()
            #print "Get Variable information"
            for v in lp.variables():
                colNames[v2n[v]] = str(v.name)
                initValues[v2n[v]] = 0.0
                if v.lowBound != None:
                    lowerBounds[v2n[v]] = v.lowBound
                else:
                    lowerBounds[v2n[v]] = -coinDblMax
                if v.upBound != None:
                    upperBounds[v2n[v]] = v.upBound
                else:
                    upperBounds[v2n[v]] = coinDblMax
            #values for constraints
            numRows =len(lp.constraints)
            NumRowDoubleArray = ctypes.c_double * numRows
            NumRowStrArray = ctypes.c_char_p * numRows
            NumRowCharArray = ctypes.c_char * numRows
            coinSense={LpConstraintEQ:"E", LpConstraintLE:"L", LpConstraintGE:"G"}
            rhsValues = NumRowDoubleArray()
            rangeValues = NumRowDoubleArray()
            rowNames = NumRowStrArray()
            rowType = NumRowCharArray()
            c2n = {}
            n2c = {}
            i = 0
            print "Get constraint information"
            for c in lp.constraints:
                rhsValues[i] = -lp.constraints[c].constant
                #range values are constraints that are >= a and <=b
                rangeValues[i] = 0.0
                rowNames[i] = str(c)
                rowType[i] = coinSense[lp.constraints[c].sense]
                c2n[c] = i
                n2c[i] = c
                i = i+1

            #return the coefficient matrix as a series of vectors
            coeffs = lp.coefficients()
            numels = len(coeffs)  #seems to be all this is good for
            NumelsDoubleArray = ctypes.c_double * numels
            NumelsIntArray = ctypes.c_int * (numels)
            elemBase = NumelsDoubleArray()
            myelemBase = []
            indBase = NumelsIntArray()
            myindBase = []
            mystartsBase = []
            mylenBase = []
            NumVarspIntArray = ctypes.c_int * (numVars + 1)
            startsBase = NumVarspIntArray()
            lenBase = NumVarspIntArray()
            if self.debug: print "get Coefficient information"
            elements = [[] for i in range(numVars)]
            for var in coeffs:
                elements[vname2n[var[0]]].append([var[1],var[2]])
            if self.debug: print "constructed array"
                
            for v in vars:
                startsBase[v2n[v]] = len (myelemBase)
                mystartsBase.append(len (myelemBase))
                myelemBase.extend((var[1] for var in elements[v2n[v]]))
                myindBase.extend((c2n[var[0]] for var in elements[v2n[v]]))
                lenBase[v2n[v]] = len(myelemBase) - startsBase[v2n[v]]
                mylenBase.append(len(myelemBase) - startsBase[v2n[v]])
            startsBase[numVars] = len(myelemBase)
            for i in range(numels):
                elemBase[i]=myelemBase[i]
                indBase[i]=myindBase[i]
            #MIP Variables
            NumVarCharArray = ctypes.c_char * numVars
            columnType = NumVarCharArray()
            if lp.isMIP():
                CoinLpCategories = {LpContinuous: "C",
                                    LpInteger: "I"}
                for v in lp.variables():
                    columnType[v2n[v]] = CoinLpCategories[v.cat]
            ##print "return all info and solve"
            return  numVars, numRows, numels, rangeCount, objectSense, objectCoeffs, \
                rhsValues, rangeValues, rowType, startsBase, lenBase, indBase, \
                elemBase, lowerBounds, upperBounds, initValues, colNames, \
                rowNames, columnType, n2v, n2c
        
    
    COIN = COINMP_DLL
except:
    class COINMP_DLL(LpSolver):
        """The COIN_MP LP MIP solver (via a DLL Windows only)"""
        def available(self):
            """True if the solver is available"""
            return False
        def actualSolve(self, lp):
            """Solve a well formulated lp problem"""
            raise RuntimeError, "COINMP_DLL: Not Available"

    COIN = COIN_MEM

# Default solver selection
if CPLEX_MEM().available():
    LpSolverDefault = CPLEX_MEM()
elif COIN_MEM().available():
    LpSolverDefault = COIN_MEM()
elif COINMP_DLL().available():
    LpSolverDefault = COINMP_DLL()
elif GLPK_MEM().available():
    LpSolverDefault = GLPK_MEM()
elif CPLEX_CMD().available():
    LpSolverDefault = CPLEX_CMD()
elif COIN_CMD().available():
    LpSolverDefault = COIN_CMD()
elif GLPK_CMD().available():
    LpSolverDefault = GLPK_CMD()
else:
    LpSolverDefault = None

class LpElement(object):
    """Base class for LpVariable and LpConstraintVar 
    """
    #to remove illegal characters from the names
    trans = string.maketrans("-+[] ","_____")
    def setname(self,name):
        if name:
            self.__name = str(name).translate(self.trans)
        else:
            self.__name = None
    def getname(self):
        return self.__name
    name = property(fget = getname,fset = setname)
    
    def __init__(self, name):
        self.name = name
         # self.hash MUST be different for each variable
        # else dict() will call the comparison operators that are overloaded
        self.hash = id(self)
        self.modified = True

    def __hash__(self):
        return self.hash

    def __str__(self):
        return self.name
    def __repr__(self):
        return self.name

    def __neg__(self):
        return - LpAffineExpression(self)
        
    def __pos__(self):
        return self

    def __nonzero__(self):
        return 1

    def __add__(self, other):
        return LpAffineExpression(self) + other

    def __radd__(self, other):
        return LpAffineExpression(self) + other
        
    def __sub__(self, other):
        return LpAffineExpression(self) - other
        
    def __rsub__(self, other):
        return other - LpAffineExpression(self)

    def __mul__(self, other):
        return LpAffineExpression(self) * other

    def __rmul__(self, other):
        return LpAffineExpression(self) * other
        
    def __div__(self, other):
        return LpAffineExpression(self)/other

    def __rdiv__(self, other):
        raise TypeError, "Expressions cannot be divided by a variable"

    def __le__(self, other):
        return LpAffineExpression(self) <= other

    def __ge__(self, other):
        return LpAffineExpression(self) >= other

    def __eq__(self, other):
        return LpAffineExpression(self) == other

    def __ne__(self, other):
        if isinstance(other, LpVariable):
            return self.name is not other.name
        elif isinstance(other, LpAffineExpression):
            if other.isAtomic():
                return self is not other.atom()
            else:
                return 1
        else:
            return 1

  
class LpVariable(LpElement):
    """A LP variable"""
    def __init__(self, name, lowBound = None, upBound = None,
                  cat = LpContinuous, e = None):
        """
        Creates an LP variable
        
        This function creates an LP Variable with the specified associated parameters
            
        Inputs:
            - name: The name of the variable used in the output .lp file
            - lowbound -- Optional: The lower bound on this variable's range. Default is negative infinity
            - upBound -- Optional: The upper bound on this variable's range. Default is positive infinity
            - cat -- Optional: The category this variable is in, Integer or Continuous(default)
            - e -- Optional: Used for column based modelling: relates to the variable's existence in the objective function and constraints
                     
        Returns:
            - An LP variable
        """
        LpElement.__init__(self,name)
        self.lowBound = lowBound
        self.upBound = upBound
        self.cat = cat
        self.varValue = None
        self.init = 0
        #code to add a variable to constraints for column based 
        # modelling
        if e:
            self.add_expression(e)

    def add_expression(self,e):
        self.expression = e
        self.addVariableToConstraints(e)

    def matrix(self, name, indexs, lowBound = None, upBound = None, cat = 0, indexStart = []):
        if not isinstance(indexs, tuple): indexs = (indexs,)
        if "%" not in name: name += "_%d" * len(indexs)

        index = indexs[0]
        indexs = indexs[1:]
        if len(indexs) == 0:
            return [LpVariable(name % tuple(indexStart + [i]), lowBound, upBound, cat) for i in index]
        else:
            return [LpVariable.matrix(name, indexs, lowBound, upBound, cat, indexStart + [i]) for i in index]
    matrix = classmethod(matrix)

    def dicts(self, name, indexs, lowBound = None, upBound = None, cat = 0, indexStart = []):
        """
        Creates a dictionary of LP variables
        
        This function creates a dictionary of LP Variables with the specified associated parameters.
            
        Inputs:
            - name: The prefix to the name of each LP variable created
            - indexs: A list of strings of the keys to the dictionary of LP variables, and the main part of the variable name itself
            - lowbound -- Optional: The lower bound on these variables' range. Default is negative infinity
            - upBound -- Optional: The upper bound on these variables' range. Default is positive infinity
            - cat -- Optional: The category these variables are in, Integer or Continuous(default)
                                 
        Returns:
            - A dictionary of LP Variables
        """
        if not isinstance(indexs, tuple): indexs = (indexs,)
        if "%" not in name: name += "_%s" * len(indexs)

        index = indexs[0]
        indexs = indexs[1:]
        d = {}
        if len(indexs) == 0:
            for i in index:
                d[i] = LpVariable(name % tuple(indexStart + [str(i)]), lowBound, upBound, cat)
        else:
            for i in index:
                d[i] = LpVariable.dicts(name, indexs, lowBound, upBound, cat, indexStart + [i])
        return d
    dicts = classmethod(dicts)

    def dict(self, name, indexs, lowBound = None, upBound = None, cat = 0):
        if not isinstance(indexs, tuple): indexs = (indexs,)
        if "%" not in name: name += "_%s" * len(indexs)

        lists = indexs

        if len(indexs)>1:
            # Cartesian product
            res = []
            while len(lists):
                first = lists[-1]
                nres = []
                if res:
                    if first:
                        for f in first:
                            nres.extend([[f]+r for r in res])
                    else:
                        nres = res
                    res = nres
                else:
                    res = [[f] for f in first]
                lists = lists[:-1]
            index = [tuple(r) for r in res]
        elif len(indexs) == 1:
            index = indexs[0]
        else:
            return {}

        d = {}
        for i in index:
         d[i] = self(name % i, lowBound, upBound, cat)
        return d
    dict = classmethod(dict)

    def bounds(self, low, up):
        self.lowBound = low
        self.upBound = up

    def positive(self):
        self.lowBound = 0
        self.upBound = None

    def value(self):
        return self.varValue
    
    def round(self, epsInt = 1e-5, eps = 1e-7):
        if self.varValue is not None:
            if self.upBound != None and self.varValue > self.upBound and self.varValue <= self.upBound + eps:
                self.varValue = self.upBound
            elif self.lowBound != None and self.varValue < self.lowBound and self.varValue >= self.lowBound - eps:
                self.varValue = self.lowBound
            if self.cat == LpInteger and abs(round(self.varValue) - self.varValue) <= epsInt:
                self.varValue = round(self.varValue)
    
    def roundedValue(self, eps = 1e-5):
        if self.cat == LpInteger and self.varValue != None \
            and abs(self.varValue - round(self.varValue)) <= eps:
            return round(self.varValue)
        else:
            return self.varValue
        
    def valueOrDefault(self):
        if self.varValue != None:
            return self.varValue
        elif self.lowBound != None:
            if self.upBound != None:
                if 0 >= self.lowBound and 0 <= self.upBound:
                    return 0
                else:
                    if self.lowBound >= 0:
                        return self.lowBound
                    else:
                        return self.upBound
            else:
                if 0 >= self.lowBound:
                    return 0
                else:
                    return self.lowBound
        elif self.upBound != None:
            if 0 <= self.upBound:
                return 0
            else:
                return self.upBound
        else:
            return 0

    def valid(self, eps):
        if self.varValue == None: return False
        if self.upBound != None and self.varValue > self.upBound + eps:
            return False
        if self.lowBound != None and self.varValue < self.lowBound - eps:
            return False
        if self.cat == LpInteger and abs(round(self.varValue) - self.varValue) > eps:
            return False
        return True

    def infeasibilityGap(self, mip = 1):
        if self.varValue == None: raise ValueError, "variable value is None"
        if self.upBound != None and self.varValue > self.upBound:
            return self.varValue - self.upBound
        if self.lowBound != None and self.varValue < self.lowBound:
            return self.varValue - self.lowBound
        if mip and self.cat == LpInteger and round(self.varValue) - self.varValue != 0:
            return round(self.varValue) - self.varValue
        return 0

    def isBinary(self):
        return self.cat == LpInteger and self.lowBound == 0 and self.upBound == 1

    def isFree(self):
        return self.lowBound == None and self.upBound == None

    def isConstant(self):
        return self.lowBound != None and self.upBound == self.lowBound

    def isPositive(self):
        return self.lowBound == 0 and self.upBound == None

    def asCplexLpVariable(self):
        if self.isFree(): return self.name + " free"
        if self.isConstant(): return self.name + " = %.12g" % self.lowBound
        if self.lowBound == None:
            s= "-inf <= "
        # Note: XPRESS and CPLEX do not interpret integer variables without 
        # explicit bounds
        elif (self.lowBound == 0 and self.cat == LpContinuous):
            s = ""
        else:
            s= "%.12g <= " % self.lowBound
        s += self.name
        if self.upBound != None:
            s+= " <= %.12g" % self.upBound
        return s

    def asCplexLpAffineExpression(self, name, constant = 1):
        return LpAffineExpression(self).asCplexLpAffineExpression(name, constant)

    def __ne__(self, other):
        if isinstance(other, LpElement):
            return self.name is not other.name
        elif isinstance(other, LpAffineExpression):
            if other.isAtomic():
                return self is not other.atom()
            else:
                return 1
        else:
            return 1
        
    def addVariableToConstraints(self,e):
        """adds a variable to the constraints indicated by
        the LpConstraintVars in e
        """
        for constraint, coeff in e.items():
            constraint.addVariable(self,coeff)
            
    def setInitialValue(self,val):
        """sets the initial value of the Variable to val
        may of may not be supported by the solver
        """ 
        


class LpAffineExpression(dict):
    """A linear combination of LP variables"""
    #to remove illegal characters from the names
    trans = string.maketrans("-+[] ","_____")
    def setname(self,name):
        if name:
            self.__name = str(name).translate(self.trans)
        else:
            self.__name = None
        
    def getname(self):
        return self.__name
        
    name = property(fget = getname,fset = setname)

    def __init__(self, e = None, constant = 0, name = None):
        self.name = name
        #TODO remove isinstance usage
        if e is None:
            e = {}
        if isinstance(e,LpAffineExpression):
            # Will not copy the name
            self.constant = e.constant
            dict.__init__(self, e)
        elif isinstance(e,dict):
            self.constant = constant
            dict.__init__(self, e)
        elif isinstance(e,LpElement):
            self.constant = 0
            dict.__init__(self, {e:1})
        else:
            self.constant = e
            dict.__init__(self)

    # Proxy functions for variables

    def isAtomic(self):
        return len(self) == 1 and self.constant == 0 and self.values()[0] == 1

    def isNumericalConstant(self):
        return len(self) == 0

    def atom(self):
        return self.keys()[0]

    # Functions on expressions

    def __nonzero__(self):
        return self.constant != 0 or len(self)

    def value(self):
        s = self.constant
        for v,x in self.iteritems():
            if v.varValue is None:
                return None
            s += v.varValue * x
        return s
        
    def valueOrDefault(self):
        s = self.constant
        for v,x in self.iteritems():
            s += v.valueOrDefault() * x
        return s
        
    def addterm(self, key, value):
            y = self.get(key, 0)
            if y:
                y += value
                if y: self[key] = y
                else: del self[key]
            else:
                self[key] = value

    def emptyCopy(self):
        return LpAffineExpression()
        
    def copy(self):
        """Make a copy of self except the name which is reset"""
        # Will not copy the name
        return LpAffineExpression(self)
        
    def __str__(self, constant = 1):
        s = ""
        for v in self:
            val = self[v]
            if val<0:
                if s != "": s += " - "
                else: s += "-"
                val = -val
            elif s != "": s += " + "
            if val == 1: s += str(v)
            else: s += str(val) + "*" + str(v)
        if constant:
            if s == "":
                s = str(self.constant)
            else:
                if self.constant < 0: s += " - " + str(-self.constant)
                elif self.constant > 0: s += " + " + str(self.constant)
        elif s == "":
            s = "0"
        return s
        
    def __repr__(self):
        l = [str(self[v]) + "*" + str(v) for v in self]
        l.append(str(self.constant))
        s = " + ".join(l)
        return s

    def asCplexLpAffineExpression(self, name, constant = 1):
        # Ugly.
        s = ""
        sl = name + ":"
        notFirst = 0
        for v,val in self.iteritems():
            if val<0:
                ns = " - "
                val = -val
            elif notFirst:
                ns = " + "
            else:
                ns = " "
            notFirst = 1
            if val == 1: ns += v.name
            else: ns += "%.12g %s" % (val, v.name)
            if len(sl)+len(ns) > LpCplexLPLineSize:
                s += sl+"\n"
                sl = ns
            else:
                sl += ns
        if not self:
            ns = " " + str(self.constant)
        else:
            ns = ""
            if constant:
                if self.constant < 0: ns = " - " + str(-self.constant)
                elif self.constant > 0: ns = " + " + str(self.constant)
        if len(sl)+len(ns) > LpCplexLPLineSize:
            s += sl+"\n"+ns+"\n"
        else:
            s += sl+ns+"\n"
        return s

    def addInPlace(self, other):
        if other is 0: return self
        if isinstance(other,LpElement):
            self.addterm(other, 1)
        elif (isinstance(other,list) 
              or isinstance(other,types.GeneratorType)):
           for e in other:
                self.addInPlace(e)
        elif isinstance(other,LpAffineExpression):
            self.constant += other.constant
            for v,x in other.iteritems():
                self.addterm(v, x)
        elif isinstance(other,dict):
            for e in other.itervalues():
                self.addInPlace(e)
        else:
            self.constant += other
        return self

    def subInPlace(self, other):
        if other is 0: return self
        if isinstance(other,LpElement):
            self.addterm(other, -1)
        elif (isinstance(other,list) 
              or isinstance(other,types.GeneratorType)):
            for e in other:
                self.subInPlace(e)
        elif isinstance(other,LpAffineExpression):
            self.constant -= other.constant
            for v,x in other.iteritems():
                self.addterm(v, -x)
        elif isinstance(other,dict):
            for e in other.itervalues():
                self.subInPlace(e)
        else:
            self.constant -= other
        return self
        
    def __neg__(self):
        e = self.emptyCopy()
        e.constant = - self.constant
        for v,x in self.iteritems():
            e[v] = - x
        return e
        
    def __pos__(self):
        return self

    def __add__(self, other):
        return self.copy().addInPlace(other)

    def __radd__(self, other):
        return self.copy().addInPlace(other)
        
    def __sub__(self, other):
        return self.copy().subInPlace(other)
        
    def __rsub__(self, other):
        return (-self).addInPlace(other)

    def __mul__(self, other):
        e = self.emptyCopy()
        if isinstance(other,LpAffineExpression):
            e.constant = self.constant * other.constant
            if len(other):
                if len(self):
                    raise TypeError, "Non-constant expressions cannot be multiplied"
                else:
                    c = self.constant
                    if c != 0:
                        for v,x in other.iteritems():
                            e[v] = c * x
            else:
                c = other.constant
                if c != 0:
                    for v,x in self.iteritems():
                        e[v] = c * x
        elif isinstance(other,LpVariable):
            return self * LpAffineExpression(other)
        else:
            if other != 0:
                e.constant = self.constant * other
                for v,x in self.iteritems():
                    e[v] = other * x
        return e

    def __rmul__(self, other):
        return self * other
        
    def __div__(self, other):
        if isinstance(other,LpAffineExpression) or isinstance(other,LpVariable):
            if len(other):
                raise TypeError, "Expressions cannot be divided by a non-constant expression"
            other = other.constant
        e = self.emptyCopy()
        e.constant = self.constant / other
        for v,x in self.iteritems():
            e[v] = x / other
        return e

    def __rdiv__(self, other):
        e = self.emptyCopy()
        if len(self):
            raise TypeError, "Expressions cannot be divided by a non-constant expression"
        c = self.constant
        if isinstance(other,LpAffineExpression):
            e.constant = other.constant / c
            for v,x in other.iteritems():
                e[v] = x / c
        else:
            e.constant = other / c
        return e

    def __le__(self, other):
        return LpConstraint(self - other, LpConstraintLE)

    def __ge__(self, other):
        return LpConstraint(self - other, LpConstraintGE)

    def __eq__(self, other):
        return LpConstraint(self - other, LpConstraintEQ)

class LpConstraint(LpAffineExpression):
    """An LP constraint"""
    def __init__(self, e = None, sense = LpConstraintEQ,
                  name = None, rhs = None):
        LpAffineExpression.__init__(self, e, name = name)
        if rhs:
            self.constant = - rhs
        self.sense = sense

    def __str__(self):
        s = LpAffineExpression.__str__(self, 0)
        if self.sense:
            s += " " + LpConstraintSenses[self.sense] + " " + str(-self.constant)
        return s

    def asCplexLpConstraint(self, name):
        # Immonde.
        s = ""
        sl = name + ":"
        notFirst = 0
        for v,val in self.iteritems():
            if val<0:
                ns = " - "
                val = -val
            elif notFirst:
                ns = " + "
            else:
                ns = " "
            notFirst = 1
            if val == 1: ns += v.name
            else: ns += "%.12g %s" % (val , v.name)
            if len(sl)+len(ns) > LpCplexLPLineSize:
                s += sl+"\n"
                sl = ns
            else:
                sl += ns
        if not self: sl += "0"
        c = -self.constant
        if c == 0: c = 0 # Supress sign
        ns = " %s %.12g" % (LpConstraintSenses[self.sense], c)
        if len(sl)+len(ns) > LpCplexLPLineSize:
            s += sl + "\n" + ns + "\n"
        else:
            s += sl + ns + "\n"
        return s

    def __repr__(self):
        s = LpAffineExpression.__repr__(self)
        s += " " + LpConstraintSenses[self.sense] + " 0"
        return s
        
    def copy(self):
        """Make a copy of self"""
        return LpConstraint(self, self.sense)
        
    def emptyCopy(self):
        return LpConstraint(sense = self.sense)

    def addInPlace(self, other):
        if isinstance(other,LpConstraint):
            if self.sense * other.sense >= 0:
                LpAffineExpression.addInPlace(self, other)  
                self.sense |= other.sense
            else:
                LpAffineExpression.subInPlace(self, other)  
                self.sense |= - other.sense
        elif isinstance(other,list):
            for e in other:
                self.addInPlace(e)
        else:
            LpAffineExpression.addInPlace(self, other)
            #raise TypeError, "Constraints and Expressions cannot be added"
        return self

    def subInPlace(self, other):
        if isinstance(other,LpConstraint):
            if self.sense * other.sense <= 0:
                LpAffineExpression.subInPlace(self, other)  
                self.sense |= - other.sense
            else:
                LpAffineExpression.addInPlace(self, other)  
                self.sense |= other.sense
        elif isinstance(other,list):
            for e in other:
                self.subInPlace(e)
        else:
            LpAffineExpression.addInPlace(self, other)
            #raise TypeError, "Constraints and Expressions cannot be added"
        return self
        
    def __neg__(self):
        c = LpAffineExpression.__neg__(self)
        c.sense = - c.sense
        return c

    def __add__(self, other):
        return self.copy().addInPlace(other)
        
    def __radd__(self, other):
        return self.copy().addInPlace(other)

    def __sub__(self, other):
        return self.copy().subInPlace(other)

    def __rsub__(self, other):
        return (-self).addInPlace(other)

    def __mul__(self, other):
        if isinstance(other,LpConstraint):
            c = LpAffineExpression.__mul__(self, other)
            if c.sense == 0:
                c.sense = other.sense
            elif other.sense != 0:
                c.sense *= other.sense
            return c
        else:
            return LpAffineExpression.__mul__(self, other)
        
    def __rmul__(self, other):
        return self * other

    def __div__(self, other):
        if isinstance(other,LpConstraint):
            c = LpAffineExpression.__div__(self, other)
            if c.sense == 0:
                c.sense = other.sense
            elif other.sense != 0:
                c.sense *= other.sense
            return c
        else:
            return LpAffineExpression.__mul__(self, other)

    def __rdiv__(self, other):
        if isinstance(other,LpConstraint):
            c = LpAffineExpression.__rdiv__(self, other)
            if c.sense == 0:
                c.sense = other.sense
            elif other.sense != 0:
                c.sense *= other.sense
            return c
        else:
            return LpAffineExpression.__mul__(self, other)

    def valid(self, eps = 0):
        val = self.value()
        if self.sense == LpConstraintEQ: return abs(val) <= eps
        else: return val * self.sense >= - eps

class LpConstraintVar(LpElement):
    """A Constraint that can be treated as a variable when constructing
    a LpProblem by columns
    """
    def __init__(self, name = None ,sense = None, 
                 rhs = None, e = None):
        LpElement.__init__(self,name)
        self.constraint = LpConstraint(name = self.name, sense = sense,
                                       rhs = rhs , e = e)
        
    def addVariable(self, var, coeff):
        """Adds more a varible to the constraint with the
        activity coeff
        """
        self.constraint.addterm(var, coeff)

class LpProblem:
    """An LP Problem"""
    def __init__(self, name = "NoName", sense = LpMinimize):
        """
        Creates an LP Problem
        
        This function creates a new LP Problem  with the specified associated parameters
            
        Inputs:
            - name -- The name of the problem used in the output .lp file
            - sense(optional) -- The LP problem objective: LpMinimize(default) or LpMaximise
                    
        Returns:
            - An LP Problem
        """
        self.objective = None
        self.constraints = {}
        self.name = name
        self.sense = sense
        self.sos1 = {}
        self.sos2 = {}
        self.status = LpStatusNotSolved
        self.noOverlap = 1
        self.solver = None
        self.initialValues = {}
        self.modifiedVariables = []
        self.modifiedConstraints = []
        self.resolveOK = False

        
        # locals
        self.lastUnused = 0

    def __repr__(self):
        string = self.name+":\n"
        if self.sense == 1:
            string += "MINIMIZE\n"
        else:
            string += "MAXIMIZE\n"
        string += repr(self.objective) +"\n"

        if self.constraints:
            string += "SUBJECT TO\n"
            for n, c in self.constraints.iteritems():
                string += c.asCplexLpConstraint(n) +"\n"
        string += "VARIABLES\n"
        for v in self.variables():
            string += v.asCplexLpVariable() + " " + LpCategories[v.cat] + "\n"
        return string

    def copy(self):
        """Make a copy of self. Expressions are copied by reference"""
        lpcopy = LpProblem(name = self.name, sense = self.sense)
        lpcopy.objective = self.objective
        lpcopy.constraints = self.constraints.copy()
        lpcopy.sos1 = self.sos1.copy()
        lpcopy.sos2 = self.sos2.copy()
        return lpcopy

    def deepcopy(self):
        """Make a copy of self. Expressions are copied by value"""
        lpcopy = LpProblem(name = self.name, sense = self.sense)
        if lpcopy.objective != None:
            lpcopy.objective = self.objective.copy()
        lpcopy.constraints = {}
        for k,v in self.constraints.iteritems():
            lpcopy.constraints[k] = v.copy()
        lpcopy.sos1 = self.sos1.copy()
        lpcopy.sos2 = self.sos2.copy()
        return lpcopy

    def normalisedNames(self):
        constraintsNames = {}
        i = 0
        for k in self.constraints:
            constraintsNames[k] = "C%07d" % i
            i += 1
        variablesNames = {}
        i = 0
        for k in self.variables():
            variablesNames[k.name] = "X%07d" % i
            i += 1
        return constraintsNames, variablesNames, "OBJ"

    def isMIP(self):
        for v in self.variables():
            if v.cat == LpInteger: return 1
        return 0

    def roundSolution(self, epsInt = 1e-5, eps = 1e-7):
        """
        Rounds the lp variables
        
        Inputs:
            - none
        
        Side Effects:
            - The lp variables are rounded
        """
        for v in self.variables():
            v.round(epsInt, eps)

    def unusedConstraintName(self):
        self.lastUnused += 1
        while 1:
            s = "_C%d" % self.lastUnused
            if s not in self.constraints: break
            self.lastUnused += 1
        return s

    def valid(self, eps = 0):
        for v in self.variables():
            if not v.valid(eps): return False
        for c in self.constraints.itervalues():
            if not c.valid(eps): return False
        else:
            return True

    def infeasibilityGap(self, mip = 1):
        gap = 0
        for v in self.variables():
            gap = max(abs(v.infeasibilityGap(mip)), gap)
        for c in self.constraints.itervalues():
            if not c.valid(0):
                gap = max(abs(c.value()), gap)
        return gap

    def variables(self):
        """
        Returns a list of the problem variables
        
        Inputs:
            - none
        
        Returns:
            - A list of the problem variables
        """
        variables = {}
        if self.objective:
            variables.update(self.objective)
        for c in self.constraints.itervalues():
            variables.update(c)
        return variables.keys()

    def variablesDict(self):
        variables = {}
        if self.objective:
            for v in self.objective:
                variables[v.name] = v
        for c in self.constraints.values():
            for v in c:
                variables[v.name] = v
        return variables
    
    def add(self, constraint, name = None):
        self.addConstraint(constraint, name)

    def addConstraint(self, constraint, name = None):
        if not isinstance(constraint, LpConstraint):
            raise TypeError, "Can only add LpConstraint objects"
        if name:
            constraint.name = name 
        try:
            if constraint.name:
                name = constraint.name
            else:
                name = self.unusedConstraintName()
        except AttributeError:
            raise TypeError, "Can only add LpConstraint objects"            
            #removed as this test fails for empty constraints
#        if len(constraint) == 0:
#            if not constraint.valid():
#                raise ValueError, "Cannot add false constraints"
        if name in self.constraints:
            if self.noOverlap:
                raise "overlapping constraint names: " + name
            else:
                print "Warning: overlapping constraint names:", name
        self.constraints[name] = constraint
        self.modifiedConstraints.append(constraint)

    def setObjective(self,obj):
        """
        Sets the input variable as the objective function. Used in Columnwise Modelling
        
        Inputs:
            - obj -- the objective function of type LpConstraintVar
            
        Side Effects:
            - The objective function is set
        """
        try:
            obj = obj.constraint
            name = obj.name
        except AttributeError:
            name = None
        self.objective = obj
        self.objective.name = name
    
    def __iadd__(self, other):
        if isinstance(other, tuple):
            other, name = other
        else:
            name = None
        if other is True:
            return self
        if isinstance(other, LpConstraintVar):
            self.addConstraint(other.constraint)
        elif isinstance(other, LpConstraint):
            self.addConstraint(other, name)
        elif isinstance(other, LpAffineExpression):
            self.objective = other
            self.objective.name = name
        elif isinstance(other, LpVariable) or type(other) in [int, float]:
            self.objective = LpAffineExpression(other)
            self.objective.name = name
        else:
            raise TypeError, "Can only add LpConstraintVar, LpConstraint, LpAffineExpression or True objects"
        return self
    
    def extend(self, contraintes):
        if isinstance(contraintes, dict):
            for name in contraintes:
                self.constraints[name] = contraintes[name]
        else:
            for c in contraintes:
                if isinstance(c,tuple):
                    name = c[0]
                    c = c[1]
                else:
                    name = None
                if not name: name = c.name
                if not name: name = self.unusedConstraintName()
                self.constraints[name] = c

    def coefficients(self, translation = None):
        coefs = []
        if translation == None:
            for c in self.constraints:
                cst = self.constraints[c]
                coefs.extend([(v.name, c, cst[v]) for v in cst])
        else:
            for c in self.constraints:
                ctr = translation[c]
                cst = self.constraints[c]
                coefs.extend([(translation[v.name], ctr, cst[v]) for v in cst])
        return coefs
        
    def writeMPS(self, filename, mpsSense = 0, rename = 0, mip = 1):
        wasNone, dummyVar = self.fixObjective()
        f = file(filename, "w")
        if mpsSense == 0: mpsSense = self.sense
        cobj = self.objective
        if mpsSense != self.sense:
            n = cobj.name
            cobj = - cobj
            cobj.name = n
        if rename:
            constraintsNames, variablesNames, cobj.name = self.normalisedNames()
        f.write("*SENSE:"+LpSenses[mpsSense]+"\n")
        n = self.name
        if rename: n = "MODEL"
        f.write("NAME          "+n+"\n")
        vs = self.variables()
        # constraints
        f.write("ROWS\n")
        objName = cobj.name
        if not objName: objName = "OBJ"
        f.write(" N  %s\n" % objName)
        mpsConstraintType = {LpConstraintLE:"L", LpConstraintEQ:"E", LpConstraintGE:"G"}
        for k,c in self.constraints.iteritems():
            if rename: k = constraintsNames[k]
            f.write(" "+mpsConstraintType[c.sense]+"  "+k+"\n")
        # matrix
        f.write("COLUMNS\n")
        # Creation of a dict of dict:
        # coefs[nomVariable][nomContrainte] = coefficient       
        coefs = {}
        for k,c in self.constraints.iteritems():
            if rename: k = constraintsNames[k]
            for v in c:
                n = v.name
                if rename: n = variablesNames[n]
                if n in coefs:
                    coefs[n][k] = c[v]
                else:
                    coefs[n] = {k:c[v]}
        
        for v in vs:
            if mip and v.cat == LpInteger:
                f.write("    MARK      'MARKER'                 'INTORG'\n")
            n = v.name
            if rename: n = variablesNames[n]
            if n in coefs:
                cv = coefs[n]
                # Most of the work is done here
                for k in cv: f.write("    %-8s  %-8s  % .5e\n" % (n,k,cv[k]))

            # objective function
            if v in cobj: f.write("    %-8s  %-8s  % .5e\n" % (n,objName,cobj[v]))
            if mip and v.cat == LpInteger:
                f.write("    MARK      'MARKER'                 'INTEND'\n")
        # right hand side
        f.write("RHS\n")
        for k,c in self.constraints.iteritems():
            c = -c.constant
            if rename: k = constraintsNames[k]
            if c == 0: c = 0
            f.write("    RHS       %-8s  % .5e\n" % (k,c))
        # bounds
        f.write("BOUNDS\n")
        for v in vs:
            n = v.name
            if rename: n = variablesNames[n]
            if v.lowBound != None and v.lowBound == v.upBound:
                f.write(" FX BND       %-8s  % .5e\n" % (n, v.lowBound))
            elif v.lowBound == 0 and v.upBound == 1 and mip and v.cat == LpInteger:
                f.write(" BV BND       %-8s\n" % n)
            else:
                if v.lowBound != None:
                    # In MPS files, variables with no bounds (i.e. >= 0)
                    # are assumed BV by COIN and CPLEX.
                    # So we explicitly write a 0 lower bound in this case.
                    if v.lowBound != 0 or (mip and v.cat == LpInteger and v.upBound == None):
                        f.write(" LO BND       %-8s  % .5e\n" % (n, v.lowBound))
                else:
                    if v.upBound != None:
                        f.write(" MI BND       %-8s\n" % n)
                    else:
                        f.write(" FR BND       %-8s\n" % n)
                if v.upBound != None:
                    f.write(" UP BND       %-8s  % .5e\n" % (n, v.upBound))
        f.write("ENDATA\n")
        f.close()
        self.restoreObjective(wasNone, dummyVar)
        # returns the variables, in writting order
        if rename == 0:
            return vs
        else:
            return vs, variablesNames, constraintsNames, cobj.name
        
    def writeLP(self, filename, writeSOS = 1, mip = 1):
        """
        Write the given Lp problem to a .lp file.
        
        This function writes the specifications (objective function,
        constraints, variables) of the defined Lp problem to a file.
        
        Inputs:
            - filename -- the name of the file to be created.          
                
        Side Effects:
            - The file is created.
        """
        f = file(filename, "w")
        f.write("\\* "+self.name+" *\\\n")
        if self.sense == 1:
            f.write("Minimize\n")
        else:
            f.write("Maximize\n")
        wasNone, dummyVar = self.fixObjective()
        objName = self.objective.name
        if not objName: objName = "OBJ"
        f.write(self.objective.asCplexLpAffineExpression(objName, constant = 0))
        f.write("Subject To\n")
        ks = self.constraints.keys()
        ks.sort()
        for k in ks:
            f.write(self.constraints[k].asCplexLpConstraint(k))
        vs = self.variables()
        vs.sort()
        # Bounds on non-"positive" variables
        # Note: XPRESS and CPLEX do not interpret integer variables without 
        # explicit bounds
        if mip:
            vg = [v for v in vs if not (v.isPositive() and v.cat == LpContinuous) \
                and not v.isBinary()]
        else:
            vg = [v for v in vs if not v.isPositive()]
        if vg:
            f.write("Bounds\n")
            for v in vg:
                f.write("%s\n" % v.asCplexLpVariable())
        # Integer non-binary variables
        if mip:
            vg = [v for v in vs if v.cat == LpInteger and not v.isBinary()]
            if vg:
                f.write("Generals\n")
                for v in vg: f.write("%s\n" % v.name)
            # Binary variables
            vg = [v for v in vs if v.isBinary()]
            if vg:
                f.write("Binaries\n")
                for v in vg: f.write("%s\n" % v.name)
        # Special Ordered Sets
        if writeSOS and (self.sos1 or self.sos2):
            f.write("SOS\n")
            if self.sos1:
                for sos in self.sos1.itervalues():
                    f.write("S1:: \n")
                    for v,val in sos.iteritems():
                        f.write(" %s: %.12g\n" % (v.name, val))
            if self.sos2:
                for sos in self.sos2.itervalues():
                    f.write("S2:: \n")
                    for v,val in sos.iteritems():
                        f.write(" %s: %.12g\n" % (v.name, val))
        f.write("End\n")
        f.close()
        self.restoreObjective(wasNone, dummyVar)
        
    def assignVarsVals(self, values):
        variables = self.variablesDict()
        for name in values:
            variables[name].varValue = values[name]
            
    def assignVarsDj(self,values):
        variables = self.variablesDict()
        for name in values:
            variables[name].dj = values[name]
            
    def assignConsPi(self, values):
        for name in values:
            self.constraints[name].pi = values[name]
            
    def assignConsSlack(self, values):
        for name in values:
            self.constraints[name].slack = float(values[name])

    def fixObjective(self):
        if self.objective is None:
            self.objective = 0
            wasNone = 1
        else:
            wasNone = 0
        if not isinstance(self.objective, LpAffineExpression):
            self.objective = LpAffineExpression(self.objective)
        if self.objective.isNumericalConstant():
            dummyVar = LpVariable("__dummy", 0, 0)
            self.objective += dummyVar
        else:
            dummyVar = None
        return wasNone, dummyVar

    def restoreObjective(self, wasNone, dummyVar):
        if wasNone:
            self.objective = None
        elif not dummyVar is None:
            self.objective -= dummyVar

    def solve(self, solver = None):
        """
        Solve the given Lp problem.
        
        This function changes the problem to make it suitable for solving
        then calls the solver.actualSolve() method to find the solution
        
        Inputs:
            - solver -- Optional: the specific solver to be used, defaults to the 
              default solver.
                
        Side Effects:
            - The attributes of the problem object are changed in 
              solver.actualSolve() to reflect the Lp solution
        """
        
        if not(solver): solver = self.solver
        if not(solver): solver = LpSolverDefault
        wasNone, dummyVar = self.fixObjective()
        #time it
        self.solutionTime = -clock()
        status = solver.actualSolve(self)
        self.solutionTime += clock()
        self.restoreObjective(wasNone, dummyVar)
        self.solver = solver
        return status
    
    def resolve(self, solver = None):
        """ resolves an Problem using the same solver as previously
        """
        if not(solver): solver = self.solver
        if self.resolveOK:
            return self.solver.actualResolve(self)
        else:
            return self.solve(solver = solver)
        
    def setSolver(self,solver = LpSolverDefault):
        """Sets the Solver for this problem useful if you are using 
        resolve
        """
        self.solver = solver
    
    def setInitial(self,values):
        self.initialValues = values
    


class LpVariableDict(dict):
    """An LP variable generator"""
    def __init__(self, name, data = {}, lowBound = None, upBound = None, cat = 0):
        self.name = name
        dict.__init__(self, data)
        
    def __getitem__(self, key):
        if key in self:
            return dict.__getitem__(self, key)
        else:
            self[key] = LpVariable(name % key, lowBound, upBound, cat)
            return self[key]

# Utility fonctions

def lpSum(vector):
    """
    Calculate the sum of a list of linear expressions
    
    Inputs:
         - vector -- A list of linear expressions
    """
    return LpAffineExpression().addInPlace(vector)

def lpDot(v1, v2):
    """Calculate the dot product of two lists of linear expressions"""
    if not isinstance(v1, list) and not isinstance(v2, list):
        return v1 * v2
    elif not isinstance(v1, list):
        return lpDot([v1]*len(v2),v2)
    elif not isinstance(v2, list):
        return lpDot(v1,[v2]*len(v1))
    else:
        return lpSum([lpDot(e1,e2) for e1,e2 in zip(v1,v2)])

def isNumber(x):
    """Returns true if x is an int of a float"""
    return type(x) in [int, float]

def value(x):
    """Returns the value of the variable/expression x, or x if it is a number"""
    if isNumber(x): return x
    else: return x.value()

def valueOrDefault(x):
    """Returns the value of the variable/expression x, or x if it is a number
    Variable wihout value (None) are affected a possible value (within their 
    bounds)."""
    if isNumber(x): return x
    else: return x.valueOrDefault()

def ctypesArrayFill(myList,type = ctypes.c_double):
    """Creates a c array with ctypes from a python list
    type is the type of the c array
    """
    ctype= type * len(myList)
    cList = ctype()
    for i,elem in enumerate(myList):
        cList[i] = elem 
    return cList

def makeDict(headers, array, default = None):
    """
    makes a list into a dictionary with the headings given in headings
    headers is a list of header lists
    array is a list with the data
    """
    result, defdict = __makeDict(headers, array, default)
    return result

def __makeDict(headers, array, default = None):
    #this is a recursive function so end the recursion as follows
    result ={}
    returndefaultvalue = None
    if len(headers) == 1:
        result.update(dict(zip(headers[0],array)))
        defaultvalue = default
    else:
        for i,h in enumerate(headers[0]):
            result[h],defaultvalue = __makeDict(headers[1:],array[i],default)          
    if default != None:
        f = lambda :defaultvalue
        defresult = collections.defaultdict(f)
        defresult.update(result)
        result = defresult
        returndefaultvalue = collections.defaultdict(f)
    return result, returndefaultvalue
        
def splitDict(Data):
    """
    Split a dictionary with lists as the data, into smaller dictionaries
    
    Inputs:
        - Data: A dictionary with lists as the values
        
    Returns:
        - A tuple of dictionaries each containing the data separately, 
          with the same dictionary keys
    """
    # find the maximum number of items in the dictionary
    maxitems = max([len(values) for values in Data.values()])
    output =[dict() for i in range(maxitems)]
    for key, values in Data.items():
        for i, val in enumerate(values):
            output[i][key] = val
             
    return tuple(output)

def configSolvers():
    """
    Configure the path the the solvers on the command line
    
    Designed to configure the file locations of the solvers from the 
    command line after installation
    """
    configlist = [(cplex_dll_path,"cplexpath","CPLEX: "),
                  (coinMP_path, "coinmppath","CoinMP dll (windows only): ")]
    print ("Please type the full path including filename and extension \n" +
           "for each solver available")
    configdict = {}
    for (default, key, msg) in configlist:
        value = raw_input(msg + "[" + str(default) +"]")
        if value:
            configdict[key] = value
    pulp.setConfigInformation(**configdict)
    
# Tests

def pulpTestCheck(prob, solver, okstatus, sol = {},
                   reducedcosts = None,
                   duals = None,
                   slacks = None,
                   eps = EPS):
    status = prob.solve(solver)
    if status not in okstatus:
        prob.writeLP("debug.lp")
        prob.writeMPS("debug.mps")
        print "Failure: status ==", status, "not in", okstatus
        raise "Tests failed for solver ", solver
    if sol:
        for v,x in sol.iteritems():
            if abs(v.varValue - x) > eps:
                prob.writeLP("debug.lp")
                prob.writeMPS("debug.mps")
                print "Test failed: var", v, "==", v.varValue, "!=", x
                raise "Tests failed for solver ", solver
    if reducedcosts:
        for v,dj in reducedcosts.iteritems():
            if abs(v.dj - dj) > eps:
                prob.writeLP("debug.lp")
                prob.writeMPS("debug.mps")
                print "Test failed: var.dj", v, "==", v.dj, "!=", dj
                raise "Tests failed for solver ", solver
    if duals:
        for cname,p in duals.iteritems():
            c = prob.constraints[cname]
            if abs(c.pi - p) > eps:
                prob.writeLP("debug.lp")
                prob.writeMPS("debug.mps")
                print "Test failed: constraint.pi", cname , "==", c.pi, "!=", p
                raise "Tests failed for solver ", solver
    if slacks:
        for cname,slack in slacks.iteritems():
            c = prob.constraints[cname]
            if abs(c.slack - slack) > eps:
                prob.writeLP("debug.lp")
                prob.writeMPS("debug.mps")
                print ("Test failed: constraint.slack", cname , "==",
                        c.slack, "!=", slack)
                raise "Tests failed for solver ", solver
        
def pulpTest1(solver):
    # Continuous
    prob = LpProblem("test1", LpMinimize)
    x = LpVariable("x", 0, 4)
    y = LpVariable("y", -1, 1)
    z = LpVariable("z", 0)
    w = LpVariable("w", 0)
    prob += x + 4*y + 9*z, "obj"
    prob += x+y <= 5, "c1"
    prob += x+z >= 10, "c2"
    prob += -y+z == 7, "c3"
    prob += w >= 0, "c4"
    pulpTestCheck(prob, solver, [LpStatusOptimal], {x:4, y:-1, z:6, w:0})

def pulpTest2(solver):
    # MIP
    prob = LpProblem("test2", LpMinimize)
    x = LpVariable("x", 0, 4)
    y = LpVariable("y", -1, 1)
    z = LpVariable("z", 0, None, LpInteger)
    prob += x + 4*y + 9*z, "obj"
    prob += x+y <= 5, "c1"
    prob += x+z >= 10, "c2"
    prob += -y+z == 7.5, "c3"
    if solver.__class__ in [COIN_CMD]:
        # COIN_CMD always return LpStatusUndefined for MIP problems
        pulpTestCheck(prob, solver, [LpStatusUndefined], {x:3, y:-0.5, z:7})
    else:
        pulpTestCheck(prob, solver, [LpStatusOptimal], {x:3, y:-0.5, z:7})

def pulpTest3(solver):
    # relaxed MIP
    prob = LpProblem("test3", LpMinimize)
    x = LpVariable("x", 0, 4)
    y = LpVariable("y", -1, 1)
    z = LpVariable("z", 0, None, LpInteger)
    prob += x + 4*y + 9*z, "obj"
    prob += x+y <= 5, "c1"
    prob += x+z >= 10, "c2"
    prob += -y+z == 7.5, "c3"
    solver.mip = 0
    pulpTestCheck(prob, solver, [LpStatusOptimal], {x:3.5, y:-1, z:6.5})

def pulpTest4(solver):
    # Feasibility only
    prob = LpProblem("test4", LpMinimize)
    x = LpVariable("x", 0, 4)
    y = LpVariable("y", -1, 1)
    z = LpVariable("z", 0, None, LpInteger)
    prob += x+y <= 5, "c1"
    prob += x+z >= 10, "c2"
    prob += -y+z == 7.5, "c3"
    if solver.__class__ in [COIN_CMD]:
        # COIN_CMD always return LpStatusUndefined
        pulpTestCheck(prob, solver, [LpStatusUndefined])
        if x.varValue is None or x.varValue is None or x.varValue is None:
            raise "Tests failed for solver ", solver
    else:
        pulpTestCheck(prob, solver, [LpStatusOptimal])

def pulpTest5(solver):
    # Infeasible
    prob = LpProblem("test5", LpMinimize)
    x = LpVariable("x", 0, 4)
    y = LpVariable("y", -1, 1)
    z = LpVariable("z", 0, 10)
    prob += x+y <= 5.2, "c1"
    prob += x+z >= 10.3, "c2"
    prob += -y+z == 17.5, "c3"
    if solver.__class__ is GLPK_CMD:
        # GLPK_CMD return codes are not enough informative
        pulpTestCheck(prob, solver, [LpStatusUndefined])
    elif solver.__class__ is CPLEX_MEM:
        # CPLEX_MEM returns InfeasibleOrUnbounded
        pulpTestCheck(prob, solver, [LpStatusInfeasible, LpStatusUndefined])
    elif solver.__class__ is CPLEX_DLL:
        # CPLEX_DLL Does not solve the problem
        pulpTestCheck(prob, solver, [LpStatusNotSolved])
    else:
        pulpTestCheck(prob, solver, [LpStatusInfeasible])

def pulpTest6(solver):
    # Integer Infeasible
    prob = LpProblem("test6", LpMinimize)
    x = LpVariable("x", 0, 4, LpInteger)
    y = LpVariable("y", -1, 1, LpInteger)
    z = LpVariable("z", 0, 10, LpInteger)
    prob += x+y <= 5.2, "c1"
    prob += x+z >= 10.3, "c2"
    prob += -y+z == 7.4, "c3"
    if solver.__class__ in [GLPK_MEM, COIN_CMD]:
        # GLPK_CMD return codes are not enough informative
        # GLPK_MEM integer return codes seems wrong
        # COIN_CMD integer return code is always LpStatusUndefined
        pulpTestCheck(prob, solver, [LpStatusUndefined])
    elif solver.__class__ is [CPLEX_MEM, GLPK_CMD]:
        # CPLEX_MEM returns InfeasibleOrUnbounded
        pulpTestCheck(prob, solver, [LpStatusInfeasible, LpStatusUndefined])
    else:
        pulpTestCheck(prob, solver, [LpStatusInfeasible])

def pulpTest7(solver):
    #Column Based modelling of PulpTest1
    prob = LpProblem("test7", LpMinimize)
    obj = LpConstraintVar("obj")
    # constraints
    a = LpConstraintVar("C1", LpConstraintLE, 5)
    b = LpConstraintVar("C2", LpConstraintGE, 10)
    c = LpConstraintVar("C3", LpConstraintEQ, 7)

    prob.setObjective(obj)
    prob += a
    prob += b
    prob += c
    # Variables
    x = LpVariable("x", 0, 4, LpContinuous, obj + a + b)
    y = LpVariable("y", -1, 1, LpContinuous, 4*obj + a - c)
    z = LpVariable("z", 0, None, LpContinuous, 9*obj + b + c)
    pulpTestCheck(prob, solver, [LpStatusOptimal], {x:4, y:-1, z:6})

def pulpTest8(solver):
    """
    Test the reporting of dual variables slacks and reduced costs
    """
    prob = LpProblem("test8", LpMinimize)
    x = LpVariable("x", 0, 4)
    y = LpVariable("y", -1, 1)
    z = LpVariable("z", 0)
    c1 = x+y <= 5
    c2 = x+z >= 10
    c3 = -y+z == 7
    
    prob += x + 4*y + 9*z, "obj"
    prob += c1, "c1"
    prob += c2,"c2"
    prob += c3,"c3"
    
    if solver.__class__ in [CPLEX_DLL, CPLEX_CMD, COINMP_DLL]:
        pulpTestCheck(prob, solver, [LpStatusOptimal],
                  sol = {x:4, y:-1, z:6}, 
                  reducedcosts = {x:0, y:12, z:0},
                  duals = {"c1":0, "c2":1, "c3":8}, 
                  slacks = {"c1":2, "c2":0, "c3":0})

def pulpTest9(solver):
    #Column Based modelling of PulpTest1 with a resolve
    prob = LpProblem("test9", LpMinimize)
    obj = LpConstraintVar("obj")
    # constraints
    a = LpConstraintVar("C1", LpConstraintLE, 5)
    b = LpConstraintVar("C2", LpConstraintGE, 10)
    c = LpConstraintVar("C3", LpConstraintEQ, 7)

    prob.setObjective(obj)
    prob += a
    prob += b
    prob += c
    
    prob.setSolver(solver)# Variables
    x = LpVariable("x", 0, 4, LpContinuous, obj + a + b)
    y = LpVariable("y", -1, 1, LpContinuous, 4*obj + a - c)
    prob.resolve()
    z = LpVariable("z", 0, None, LpContinuous, 9*obj + b + c)
    prob.resolve()
    #difficult to check this is doing what we want as the resolve is 
    #over ridden if it is not implemented
    #pulpTestCheck(prob, solver, [LpStatusOptimal], {x:4, y:-1, z:6})

def pulpTestSolver(solver):
    tests = [pulpTest1, pulpTest2, pulpTest3, pulpTest4,
        pulpTest5, pulpTest6, pulpTest7, pulpTest8, pulpTest9]
    for t in tests:
        t(solver(msg=0))

def pulpTestAll():
    solvers = [CPLEX_MEM, CPLEX_DLL, #CPLEX_CMD,
        COIN_MEM, COIN_CMD, COINMP_DLL,
        GLPK_MEM, GLPK_CMD,
        XPRESS]

    for s in solvers:
        if s().available():
            pulpTestSolver(s)
            print "* Solver", s, "passed."
        else:
            print "Solver", s, "unavailable."


if __name__ == '__main__':
    # Tests
    pulpTestAll()
    import doctest
    doctest.testmod()
