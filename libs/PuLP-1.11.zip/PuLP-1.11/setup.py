#!/usr/bin/env/python
""" Setup script for PuLP 1.10 added by Stuart Mitchell 2007
Copyright 2007 Stuart Mitchell
"""
#TODO: use this file to make the extensions 
from distutils.core import setup

setup(name="PuLP",
      version="1.11",
      description="""PuLP is an LP modeler written in python. PuLP can generate MPS or LP files
and call GLPK[1], COIN CLP/CBC[2], CPLEX[3] and XPRESS[4] to solve linear
problems.""",
      author="J.S. Roy and S.A. Mitchell",
      author_email="s.mitchell@auckland.ac.nz",
      url="http://www.esc.auckland.ac.nz/pulp/",
      py_modules=["pulp.pulp","pulp.sparse"],
      package_dir={'pulp':'src'},
      packages = ['pulp'],
      package_data = {'pulp' : ["AUTHORS","LICENSE","pulp.cfg",
                                "CoinMP.dll","LICENSE.CoinMP.txt",
                                "AUTHORS.CoinMP.txt","README.CoinMP.txt"]}
      )
